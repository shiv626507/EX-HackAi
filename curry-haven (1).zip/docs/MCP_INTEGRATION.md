# MCP Integration Guide for StudyBuddy AI

## Overview
This guide explains how to set up and use Model Context Protocol (MCP) integrations for cross-device and platform compatibility in the StudyBuddy AI platform.

## Available MCP Integrations

### 🗄️ **Database & Backend Services**
- **Neon**: Serverless PostgreSQL for user data and progress tracking
- **Supabase**: Real-time database with authentication and file storage
- **Prisma**: Database ORM for seamless data management

### 🚀 **Deployment & Hosting**
- **Netlify**: Static site hosting with serverless functions
- **Vercel**: Frontend deployment with edge functions

### 🔗 **Automation & Workflows**  
- **Zapier**: Connect to 8,000+ apps for workflow automation

### 📋 **Project Management & Documentation**
- **Linear**: Issue tracking and project management
- **Notion**: Documentation and knowledge management

### 🎨 **Design & Content**
- **Figma**: Design to code conversion with Builder.io plugin
- **Builder CMS**: Content management for dynamic study materials

### 🔍 **Monitoring & Analytics**
- **Sentry**: Error tracking and performance monitoring

### 📖 **Documentation & Context**
- **Context7**: Up-to-date documentation for libraries and frameworks

### 🔒 **Security**
- **Semgrep**: Code security scanning and vulnerability detection

## Setup Instructions

### Step 1: Connect MCP Servers
1. Click [Open MCP popover](#open-mcp-popover) in the Builder.io interface
2. Select the MCP servers you want to connect
3. Follow the authentication prompts for each service

### Step 2: Database Setup (Required)

#### Option A: Neon (Recommended)
```bash
# Connect to Neon for PostgreSQL database
# Click "Connect to Neon" in MCP popover
```

#### Option B: Supabase  
```bash
# Connect to Supabase for real-time features
# Click "Connect to Supabase" in MCP popover
```

### Step 3: Deployment Setup

#### Netlify Deployment
```bash
# Connect to Netlify for hosting
# Click "Connect to Netlify" in MCP popover
```

#### Vercel Deployment (Alternative)
```bash
# Connect to Vercel for hosting
# Click "Connect to Vercel" in MCP popover
```

## Database Schema Setup

### User Management Tables
```sql
-- Users table
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR(255) UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  selected_exam VARCHAR(50),
  preferred_language VARCHAR(5) DEFAULT 'en',
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- User progress tracking
CREATE TABLE user_progress (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id),
  subject VARCHAR(100) NOT NULL,
  topic VARCHAR(255) NOT NULL,
  progress_percentage INTEGER DEFAULT 0,
  last_studied TIMESTAMP DEFAULT NOW(),
  study_time_minutes INTEGER DEFAULT 0
);

-- Study sessions
CREATE TABLE study_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id),
  session_type VARCHAR(50), -- 'individual', 'group', 'ai_chat'
  subject VARCHAR(100),
  duration_minutes INTEGER,
  score INTEGER,
  completed_at TIMESTAMP DEFAULT NOW()
);

-- Group study rooms
CREATE TABLE study_rooms (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(255) NOT NULL,
  subject VARCHAR(100) NOT NULL,
  exam_type VARCHAR(50) NOT NULL,
  max_participants INTEGER DEFAULT 50,
  created_by UUID REFERENCES users(id),
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Study room participants
CREATE TABLE room_participants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  room_id UUID REFERENCES study_rooms(id),
  user_id UUID REFERENCES users(id),
  joined_at TIMESTAMP DEFAULT NOW(),
  is_moderator BOOLEAN DEFAULT false
);
```

### AI Interaction Tables
```sql
-- AI chat sessions
CREATE TABLE ai_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id),
  session_type VARCHAR(50), -- 'doubt_solving', 'practice', 'explanation'
  subject VARCHAR(100),
  language VARCHAR(5) DEFAULT 'en',
  created_at TIMESTAMP DEFAULT NOW()
);

-- AI messages
CREATE TABLE ai_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id UUID REFERENCES ai_sessions(id),
  message_type VARCHAR(20), -- 'user', 'assistant'
  content TEXT NOT NULL,
  media_type VARCHAR(20), -- 'text', 'audio', 'image', 'video'
  media_url TEXT,
  timestamp TIMESTAMP DEFAULT NOW()
);
```

## Environment Variables Setup

### Required Environment Variables
```bash
# Database Configuration
DATABASE_URL="postgresql://username:password@host:port/database"

# AI Service APIs
OPENAI_API_KEY="your_openai_api_key"
GEMINI_API_KEY="your_gemini_api_key" 
WHISPER_API_KEY="your_whisper_api_key"

# Authentication
JWT_SECRET="your_jwt_secret"
SESSION_SECRET="your_session_secret"

# File Storage (if using Supabase)
SUPABASE_URL="your_supabase_url"
SUPABASE_ANON_KEY="your_supabase_anon_key"
SUPABASE_SERVICE_KEY="your_supabase_service_key"

# Real-time Communication
WEBSOCKET_PORT=3001
REDIS_URL="redis://localhost:6379"

# Email Service (for notifications)
SMTP_HOST="smtp.gmail.com"
SMTP_PORT=587
SMTP_USER="your_email@gmail.com"
SMTP_PASS="your_app_password"
```

## API Integration Examples

### Neon Database Connection
```typescript
// lib/database.ts
import { Pool } from 'pg';

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
});

export async function getUserProgress(userId: string) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      'SELECT * FROM user_progress WHERE user_id = $1',
      [userId]
    );
    return result.rows;
  } finally {
    client.release();
  }
}
```

### Supabase Real-time Setup
```typescript
// lib/supabase.ts
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_ANON_KEY!
);

// Real-time study room updates
export function subscribeToStudyRoom(roomId: string, callback: Function) {
  return supabase
    .channel(`room:${roomId}`)
    .on('postgres_changes', 
      { event: '*', schema: 'public', table: 'room_participants' },
      callback
    )
    .subscribe();
}
```

## Cross-Platform Sync Implementation

### Device Registration
```typescript
// lib/device-sync.ts
interface DeviceInfo {
  deviceId: string;
  deviceType: 'mobile' | 'tablet' | 'desktop';
  platform: 'ios' | 'android' | 'web';
  lastSeen: Date;
}

export class DeviceSyncManager {
  async registerDevice(userId: string, deviceInfo: DeviceInfo) {
    // Register device with MCP-enabled sync
    await this.updateDeviceRegistry(userId, deviceInfo);
  }

  async syncStudySession(sessionData: any) {
    // Sync across all user devices
    await this.broadcastToDevices(sessionData);
  }
}
```

### Session Handoff
```typescript
// lib/session-handoff.ts
export class SessionHandoff {
  async saveSessionState(sessionId: string, state: any) {
    // Save current session state to cloud
    await supabase
      .from('session_states')
      .upsert({ session_id: sessionId, state, updated_at: new Date() });
  }

  async restoreSessionState(sessionId: string) {
    // Restore session on new device
    const { data } = await supabase
      .from('session_states')
      .select('state')
      .eq('session_id', sessionId)
      .single();
    
    return data?.state;
  }
}
```

## Deployment with MCP

### Netlify Deployment
```yaml
# netlify.toml
[build]
  command = "pnpm build"
  publish = "dist"

[build.environment]
  NODE_VERSION = "18"

[[redirects]]
  from = "/api/*"
  to = "/.netlify/functions/:splat"
  status = 200

[dev]
  command = "pnpm dev"
  port = 8080
  publish = "dist"
```

### Vercel Deployment
```json
{
  "name": "studybuddy-ai",
  "version": 2,
  "builds": [
    {
      "src": "package.json",
      "use": "@vercel/node"
    }
  ],
  "routes": [
    {
      "src": "/api/(.*)",
      "dest": "/api/$1"
    },
    {
      "src": "/(.*)",
      "dest": "/index.html"
    }
  ],
  "env": {
    "DATABASE_URL": "@database-url",
    "OPENAI_API_KEY": "@openai-api-key",
    "GEMINI_API_KEY": "@gemini-api-key"
  }
}
```

## Monitoring & Analytics Integration

### Sentry Error Tracking
```typescript
// lib/monitoring.ts
import * as Sentry from "@sentry/react";

Sentry.init({
  dsn: process.env.SENTRY_DSN,
  environment: process.env.NODE_ENV,
  integrations: [
    new Sentry.BrowserTracing(),
  ],
  tracesSampleRate: 1.0,
});

export function trackStudyEvent(eventName: string, properties: any) {
  Sentry.addBreadcrumb({
    category: 'study',
    message: eventName,
    data: properties,
    level: 'info',
  });
}
```

## Automation with Zapier

### Study Reminder Automation
```typescript
// Webhook endpoint for Zapier integration
// POST /api/zapier/study-reminder
export async function handleStudyReminder(req: Request, res: Response) {
  const { userId, reminderType, scheduledTime } = req.body;
  
  // Trigger Zapier workflow
  await fetch('https://hooks.zapier.com/hooks/catch/your_webhook_url', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      user_id: userId,
      reminder_type: reminderType,
      scheduled_time: scheduledTime
    })
  });
  
  res.json({ success: true });
}
```

## Security Best Practices

### API Key Management
```typescript
// lib/security.ts
export class SecurityManager {
  static validateAPIKey(keyType: string): boolean {
    const key = process.env[`${keyType.toUpperCase()}_API_KEY`];
    return key && key.length > 0;
  }

  static sanitizeUserInput(input: string): string {
    // Sanitize user input for AI queries
    return input.replace(/<script[^>]*>.*?<\/script>/gi, '');
  }
}
```

## Testing MCP Integrations

### Integration Tests
```typescript
// tests/mcp-integration.test.ts
import { describe, it, expect } from 'vitest';

describe('MCP Integrations', () => {
  it('should connect to Neon database', async () => {
    const connection = await connectToNeon();
    expect(connection).toBeDefined();
  });

  it('should sync data across devices', async () => {
    const syncResult = await syncDeviceData(mockSessionData);
    expect(syncResult.success).toBe(true);
  });

  it('should deploy to Netlify successfully', async () => {
    const deployResult = await deployToNetlify();
    expect(deployResult.status).toBe('deployed');
  });
});
```

## Troubleshooting

### Common Issues
1. **Database Connection Failed**: Check DATABASE_URL and network connectivity
2. **API Rate Limits**: Implement proper rate limiting and retry logic
3. **Cross-Origin Issues**: Configure CORS properly for cross-device sync
4. **Session Sync Delays**: Optimize WebSocket connections and data payload size

### Debug Commands
```bash
# Check database connection
pnpm run db:check

# Test API integrations
pnpm run test:integration

# Validate environment variables
pnpm run env:validate

# Monitor real-time connections
pnpm run monitor:websockets
```

## Next Steps

1. **Set up your preferred database** (Neon or Supabase)
2. **Configure deployment platform** (Netlify or Vercel)
3. **Connect monitoring tools** (Sentry for error tracking)
4. **Set up automation** (Zapier for workflows)
5. **Test cross-device sync** functionality

For detailed setup instructions for each MCP server, click [Open MCP popover](#open-mcp-popover) and follow the connection guides.
