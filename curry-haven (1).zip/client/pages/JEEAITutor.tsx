import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Brain, 
  Send, 
  Mic, 
  Upload, 
  Image as ImageIcon,
  Calculator,
  BookOpen,
  Lightbulb,
  Target,
  Clock,
  Star,
  ArrowRight,
  CheckCircle,
  Copy,
  ThumbsUp,
  ThumbsDown,
  RotateCcw,
  GraduationCap,
  Sparkles,
  MessageSquare,
  HelpCircle,
  BarChart3,
  Award,
  Users,
  Loader2
} from "lucide-react";

interface ChatMessage {
  id: string;
  type: 'user' | 'ai';
  content: string;
  timestamp: Date;
  subject?: 'Physics' | 'Chemistry' | 'Mathematics';
  attachments?: any[];
  isLoading?: boolean;
  hasSteps?: boolean;
  rating?: 'up' | 'down';
}

interface QuickQuestion {
  id: string;
  question: string;
  subject: 'Physics' | 'Chemistry' | 'Mathematics';
  topic: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
}

const quickQuestions: QuickQuestion[] = [
  {
    id: '1',
    question: 'Explain the concept of electromagnetic induction',
    subject: 'Physics',
    topic: 'Electromagnetism',
    difficulty: 'Medium'
  },
  {
    id: '2',
    question: 'What is hybridization in organic chemistry?',
    subject: 'Chemistry',
    topic: 'Chemical Bonding',
    difficulty: 'Medium'
  },
  {
    id: '3',
    question: 'How to solve integration by parts?',
    subject: 'Mathematics',
    topic: 'Calculus',
    difficulty: 'Hard'
  },
  {
    id: '4',
    question: 'Derive the kinematic equations of motion',
    subject: 'Physics',
    topic: 'Kinematics',
    difficulty: 'Easy'
  }
];

const commonFormulas = [
  { subject: 'Physics', formula: 'F = ma', description: 'Newton\'s Second Law' },
  { subject: 'Physics', formula: 'E = mc²', description: 'Mass-Energy Equivalence' },
  { subject: 'Chemistry', formula: 'PV = nRT', description: 'Ideal Gas Law' },
  { subject: 'Mathematics', formula: '∫f(x)dx', description: 'Integration' }
];

const tutorFeatures = [
  {
    icon: Brain,
    title: 'Step-by-Step Solutions',
    description: 'Get detailed explanations for every JEE problem',
    color: 'text-blue-600',
    bgColor: 'bg-blue-50'
  },
  {
    icon: Calculator,
    title: 'Formula Derivations',
    description: 'Understand how formulas are derived from first principles',
    color: 'text-green-600',
    bgColor: 'bg-green-50'
  },
  {
    icon: Lightbulb,
    title: 'Concept Clarification',
    description: 'Clear your doubts with easy-to-understand explanations',
    color: 'text-yellow-600',
    bgColor: 'bg-yellow-50'
  },
  {
    icon: Target,
    title: 'JEE-Specific Help',
    description: 'Solutions tailored for JEE Main & Advanced patterns',
    color: 'text-purple-600',
    bgColor: 'bg-purple-50'
  }
];

export default function JEEAITutor() {
  const navigate = useNavigate();
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      type: 'ai',
      content: '👋 Hello! I\'m your JEE AI Tutor. I can help you with Physics, Chemistry, and Mathematics problems. Ask me anything about JEE concepts, formulas, or problem-solving techniques!',
      timestamp: new Date()
    }
  ]);
  const [newMessage, setNewMessage] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [selectedSubject, setSelectedSubject] = useState<string>('all');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async () => {
    if (!newMessage.trim()) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      type: 'user',
      content: newMessage,
      timestamp: new Date(),
      subject: selectedSubject !== 'all' ? selectedSubject as any : undefined
    };

    setMessages(prev => [...prev, userMessage]);
    setNewMessage('');
    setIsLoading(true);

    // Simulate AI response
    setTimeout(() => {
      const aiResponse = generateAIResponse(newMessage, selectedSubject);
      setMessages(prev => [...prev, aiResponse]);
      setIsLoading(false);
    }, 2000);
  };

  const generateAIResponse = (question: string, subject: string): ChatMessage => {
    const physicsSolution = `🔬 Physics Solution:

Let me break this down step by step:

Step 1: Understanding the Problem
This is a fundamental concept in JEE Physics. Let me explain the underlying principles.

Step 2: Formula Application
We'll use the relevant physics formulas: F = ma, v = u + at, etc.

Step 3: Calculation
Here's how we solve it mathematically:
- Given values: [values]
- Required: [what to find]  
- Solution: [detailed calculation]

Step 4: JEE Tips
💡 Remember: This type of question often appears in JEE Main. Focus on understanding the concept rather than memorizing.

Additional Practice:
Try similar problems from your JEE Physics textbook.`;

    const chemistrySolution = `🧪 Chemistry Solution:

Let me explain this concept clearly:

Step 1: Concept Understanding
This relates to fundamental chemistry principles that are crucial for JEE.

Step 2: Mechanism/Reaction
Here's the detailed mechanism or reaction pathway:
- Initial state: [description]
- Transition: [process]
- Final state: [result]

Step 3: JEE Application
This concept frequently appears in:
- JEE Main: Usually in [context]
- JEE Advanced: Often combined with [related topics]

Memory Tip:
🎯 Use the mnemonic: [helpful memory aid]

Practice Questions:
Look for similar problems in previous year JEE papers (2020-2024).`;

    const mathSolution = `📐 Mathematics Solution:

Let's solve this systematically:

Step 1: Problem Analysis
Identify what type of mathematical problem this is and the approach needed.

Step 2: Method Selection
For this problem, we'll use:
- [Mathematical method/theorem]
- [Relevant formulas]

Step 3: Detailed Solution
Given: [given information]
To find: [what needs to be found]
Solution: [Step-by-step mathematical working]

Step 4: Verification
Always check your answer by [verification method].

JEE Strategy:
✨ This type of problem requires [specific approach]. Practice similar questions from [chapter/topic].`;

    const generalResponse = `🎓 JEE AI Tutor Response:

Great question! This is an important topic for JEE preparation.

Key Concepts:
- [Main concept 1]
- [Main concept 2]
- [Main concept 3]

JEE Relevance:
This topic is frequently tested in both JEE Main and Advanced. Understanding this will help you solve related problems more efficiently.

Study Tips:
1. Practice regularly with previous year questions
2. Focus on understanding concepts rather than rote learning
3. Connect this topic with related concepts

Next Steps:
Try practicing 5-10 problems on this topic and come back if you need help with specific questions!`;

    let responseContent = generalResponse;
    if (subject === 'Physics') responseContent = physicsSolution;
    else if (subject === 'Chemistry') responseContent = chemistrySolution;
    else if (subject === 'Mathematics') responseContent = mathSolution;

    return {
      id: Date.now().toString(),
      type: 'ai',
      content: responseContent,
      timestamp: new Date(),
      subject: subject !== 'all' ? subject as any : undefined,
      hasSteps: true
    };
  };

  const handleQuickQuestion = (question: QuickQuestion) => {
    setNewMessage(question.question);
    setSelectedSubject(question.subject);
  };

  const handleRateMessage = (messageId: string, rating: 'up' | 'down') => {
    setMessages(prev => prev.map(msg => 
      msg.id === messageId ? { ...msg, rating } : msg
    ));
  };

  const getSubjectColor = (subject: string) => {
    switch (subject) {
      case 'Physics': return 'bg-blue-100 text-blue-700';
      case 'Chemistry': return 'bg-orange-100 text-orange-700';
      case 'Mathematics': return 'bg-purple-100 text-purple-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const clearChat = () => {
    setMessages([
      {
        id: '1',
        type: 'ai',
        content: '👋 Chat cleared! How can I help you with your JEE preparation today?',
        timestamp: new Date()
      }
    ]);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-50">
      {/* Header */}
      <header className="border-b bg-white/90 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button variant="outline" onClick={() => navigate("/dashboard")}>
                ← Back to Dashboard
              </Button>
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-xl flex items-center justify-center shadow-lg">
                  <Brain className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-gradient-jee">JEE AI Tutor</h1>
                  <p className="text-sm text-muted-foreground">Your personal AI-powered study assistant</p>
                </div>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <Badge className="bg-green-100 text-green-700 border-0 font-bold px-4 py-2">
                ✨ AI-Powered
              </Badge>
              <Button onClick={clearChat} variant="outline" size="sm">
                <RotateCcw className="w-4 h-4 mr-2" />
                Clear Chat
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Main Chat Interface */}
          <div className="lg:col-span-3">
            <Card className="shadow-2xl border-0 h-[calc(100vh-200px)] flex flex-col">
              {/* Chat Header */}
              <CardHeader className="border-b">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-full flex items-center justify-center">
                      <Brain className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <CardTitle className="text-lg">JEE AI Tutor</CardTitle>
                      <CardDescription>Ask any JEE question - Physics, Chemistry, or Math</CardDescription>
                    </div>
                  </div>
                  
                  {/* Subject Filter */}
                  <div className="flex items-center space-x-2">
                    <span className="text-sm text-muted-foreground">Subject:</span>
                    <select 
                      value={selectedSubject} 
                      onChange={(e) => setSelectedSubject(e.target.value)}
                      className="px-3 py-1 border rounded-lg text-sm"
                    >
                      <option value="all">All Subjects</option>
                      <option value="Physics">Physics</option>
                      <option value="Chemistry">Chemistry</option>
                      <option value="Mathematics">Mathematics</option>
                    </select>
                  </div>
                </div>
              </CardHeader>

              {/* Chat Messages */}
              <div className="flex-1 overflow-y-auto p-6 space-y-4">
                {messages.map((message) => (
                  <div key={message.id} className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-3xl ${message.type === 'user' ? 'ml-12' : 'mr-12'}`}>
                      <div className="flex items-start space-x-3">
                        {message.type === 'ai' && (
                          <Avatar className="w-8 h-8 border-2 border-purple-200">
                            <AvatarFallback className="bg-gradient-to-br from-purple-500 to-indigo-600 text-white text-xs">
                              AI
                            </AvatarFallback>
                          </Avatar>
                        )}
                        
                        <div className={`rounded-2xl p-4 ${
                          message.type === 'user' 
                            ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white' 
                            : 'bg-white border-2 border-gray-100'
                        }`}>
                          {message.subject && (
                            <Badge className={`${getSubjectColor(message.subject)} border-0 mb-2`}>
                              {message.subject}
                            </Badge>
                          )}
                          
                          <div className={`whitespace-pre-wrap ${message.type === 'user' ? 'text-white' : 'text-gray-800'}`}>
                            {message.content}
                          </div>
                          
                          <div className="flex items-center justify-between mt-3">
                            <span className={`text-xs ${message.type === 'user' ? 'text-white/70' : 'text-gray-500'}`}>
                              {message.timestamp.toLocaleTimeString()}
                            </span>
                            
                            {message.type === 'ai' && (
                              <div className="flex items-center space-x-2">
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => navigator.clipboard.writeText(message.content)}
                                  className="h-6 px-2"
                                >
                                  <Copy className="w-3 h-3" />
                                </Button>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => handleRateMessage(message.id, 'up')}
                                  className={`h-6 px-2 ${message.rating === 'up' ? 'text-green-600' : ''}`}
                                >
                                  <ThumbsUp className="w-3 h-3" />
                                </Button>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => handleRateMessage(message.id, 'down')}
                                  className={`h-6 px-2 ${message.rating === 'down' ? 'text-red-600' : ''}`}
                                >
                                  <ThumbsDown className="w-3 h-3" />
                                </Button>
                              </div>
                            )}
                          </div>
                        </div>
                        
                        {message.type === 'user' && (
                          <Avatar className="w-8 h-8 border-2 border-blue-200">
                            <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-600 text-white text-xs">
                              ME
                            </AvatarFallback>
                          </Avatar>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
                
                {isLoading && (
                  <div className="flex justify-start">
                    <div className="max-w-3xl mr-12">
                      <div className="flex items-start space-x-3">
                        <Avatar className="w-8 h-8 border-2 border-purple-200">
                          <AvatarFallback className="bg-gradient-to-br from-purple-500 to-indigo-600 text-white text-xs">
                            AI
                          </AvatarFallback>
                        </Avatar>
                        <div className="bg-white border-2 border-gray-100 rounded-2xl p-4">
                          <div className="flex items-center space-x-2">
                            <Loader2 className="w-4 h-4 animate-spin text-purple-600" />
                            <span className="text-gray-600">AI is thinking...</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
                
                <div ref={messagesEndRef} />
              </div>

              {/* Chat Input */}
              <div className="border-t p-4">
                <div className="flex items-center space-x-2">
                  <div className="flex-1 relative">
                    <input
                      type="text"
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      placeholder="Ask any JEE question - Physics, Chemistry, or Mathematics..."
                      className="w-full p-4 pr-32 border-2 rounded-xl text-lg"
                      onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                    />
                    <div className="absolute right-3 top-1/2 transform -translate-y-1/2 flex space-x-2">
                      <Button size="sm" variant="ghost" onClick={() => setIsRecording(!isRecording)}>
                        <Mic className={`w-4 h-4 ${isRecording ? 'text-red-500' : ''}`} />
                      </Button>
                      <Button size="sm" variant="ghost">
                        <Upload className="w-4 h-4" />
                      </Button>
                      <Button size="sm" variant="ghost">
                        <ImageIcon className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                  <Button
                    onClick={handleSendMessage}
                    disabled={!newMessage.trim() || isLoading}
                    className="gradient-jee-primary text-white border-0 px-6 py-4"
                  >
                    <Send className="w-5 h-5" />
                  </Button>
                </div>
              </div>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            {/* AI Tutor Features */}
            <Card className="shadow-xl border-0">
              <CardHeader>
                <CardTitle className="flex items-center text-lg">
                  <Sparkles className="w-5 h-5 mr-2 text-purple-600" />
                  AI Features
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {tutorFeatures.map((feature, index) => (
                    <div key={index} className={`p-3 ${feature.bgColor} rounded-lg`}>
                      <div className="flex items-center space-x-2 mb-1">
                        <feature.icon className={`w-4 h-4 ${feature.color}`} />
                        <h3 className="font-semibold text-sm">{feature.title}</h3>
                      </div>
                      <p className="text-xs text-muted-foreground">{feature.description}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Quick Questions */}
            <Card className="shadow-xl border-0">
              <CardHeader>
                <CardTitle className="flex items-center text-lg">
                  <HelpCircle className="w-5 h-5 mr-2 text-blue-600" />
                  Quick Questions
                </CardTitle>
                <CardDescription>Popular JEE questions to get started</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {quickQuestions.map((question) => (
                    <div
                      key={question.id}
                      onClick={() => handleQuickQuestion(question)}
                      className="p-3 border-2 rounded-lg cursor-pointer hover:border-primary hover:bg-blue-50 transition-all"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <Badge className={`${getSubjectColor(question.subject)} border-0 text-xs`}>
                          {question.subject}
                        </Badge>
                        <Badge variant="outline" className="text-xs">
                          {question.difficulty}
                        </Badge>
                      </div>
                      <p className="text-sm font-medium leading-relaxed">{question.question}</p>
                      <p className="text-xs text-muted-foreground mt-1">{question.topic}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Common Formulas */}
            <Card className="shadow-xl border-0">
              <CardHeader>
                <CardTitle className="flex items-center text-lg">
                  <Calculator className="w-5 h-5 mr-2 text-green-600" />
                  Quick Formulas
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {commonFormulas.map((formula, index) => (
                    <div key={index} className="p-3 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100 transition-all">
                      <div className="flex items-center justify-between mb-1">
                        <Badge className={`${getSubjectColor(formula.subject)} border-0 text-xs`}>
                          {formula.subject}
                        </Badge>
                      </div>
                      <div className="font-mono text-sm font-bold mb-1">{formula.formula}</div>
                      <p className="text-xs text-muted-foreground">{formula.description}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Study Stats */}
            <Card className="shadow-xl border-0">
              <CardHeader>
                <CardTitle className="flex items-center text-lg">
                  <BarChart3 className="w-5 h-5 mr-2 text-orange-600" />
                  AI Chat Stats
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Questions Asked</span>
                    <span className="font-bold text-blue-600">{Math.max(0, messages.length - 1)}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Physics Doubts</span>
                    <span className="font-bold text-blue-600">
                      {messages.filter(m => m.subject === 'Physics').length}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Chemistry Doubts</span>
                    <span className="font-bold text-orange-600">
                      {messages.filter(m => m.subject === 'Chemistry').length}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Math Doubts</span>
                    <span className="font-bold text-purple-600">
                      {messages.filter(m => m.subject === 'Mathematics').length}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="shadow-xl border-0">
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button variant="outline" className="w-full justify-start">
                  <BookOpen className="w-4 h-4 mr-2" />
                  JEE Syllabus
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <MessageSquare className="w-4 h-4 mr-2" />
                  Previous Papers
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Users className="w-4 h-4 mr-2" />
                  Study Groups
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
