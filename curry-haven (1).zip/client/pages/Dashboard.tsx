import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  BookOpen, 
  Brain, 
  Users, 
  BarChart3, 
  Calendar, 
  Clock, 
  Target, 
  Mic, 
  Video, 
  FileText, 
  MessageSquare, 
  Settings, 
  Bell,
  Search,
  Filter,
  Play,
  Pause,
  Volume2,
  Upload,
  Download,
  Share2,
  Star,
  TrendingUp,
  Award,
  Zap,
  Globe,
  ChevronRight,
  Plus,
  ArrowRight,
  CheckCircle
} from "lucide-react";

const examData = {
  jee: { name: "JEE Main & Advanced", icon: "🔬", color: "blue" },
  cat: { name: "CAT", icon: "💼", color: "purple" },
  gate: { name: "GATE", icon: "⚙️", color: "indigo" },
  nda: { name: "NDA & NA", icon: "🛡️", color: "green" },
  afcat: { name: "AFCAT", icon: "✈️", color: "orange" },
  cds: { name: "CDS", icon: "🎖️", color: "teal" },
  gmat: { name: "GMAT", icon: "🌍", color: "red" }
};

export default function Dashboard() {
  const { examId } = useParams<{ examId: string }>();
  const navigate = useNavigate();
  const [selectedLanguage, setSelectedLanguage] = useState<"en" | "hi">("en");
  const [isRecording, setIsRecording] = useState(false);

  const exam = examId ? examData[examId as keyof typeof examData] : null;

  useEffect(() => {
    if (!exam) {
      navigate("/exam-selection");
    }
  }, [exam, navigate]);

  if (!exam) {
    return null;
  }

  const weeklyProgress = [
    { subject: "Physics", progress: 78, change: +5 },
    { subject: "Chemistry", progress: 85, change: +2 },
    { subject: "Mathematics", progress: 72, change: +8 }
  ];

  const studyRooms = [
    { id: 1, name: "JEE Physics - Thermodynamics", participants: 234, isLive: true, difficulty: "Advanced" },
    { id: 2, name: "Organic Chemistry Doubt Session", participants: 156, isLive: true, difficulty: "Intermediate" },
    { id: 3, name: "Mathematics Integration Practice", participants: 89, isLive: false, difficulty: "Basic" }
  ];

  const recentActivity = [
    { type: "quiz", subject: "Physics", score: 85, time: "2 hours ago" },
    { type: "study", subject: "Chemistry", duration: "45 min", time: "4 hours ago" },
    { type: "group", subject: "Mathematics", activity: "Joined study room", time: "6 hours ago" }
  ];

  const aiInsights = [
    "Focus more on Thermodynamics - 23% improvement needed",
    "You're performing well in Organic Chemistry - keep it up!",
    "Schedule more practice tests for better time management",
    "Join more group sessions for Kinematics concepts"
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 gradient-purple rounded-lg flex items-center justify-center">
                <BookOpen className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gradient">StudyBuddy AI</h1>
                <p className="text-xs text-muted-foreground">{exam.name} Dashboard</p>
              </div>
              <div className="hidden md:flex items-center space-x-2 ml-8">
                <span className="text-2xl">{exam.icon}</span>
                <Badge className={`bg-${exam.color}-100 text-${exam.color}-700`}>
                  {exam.name}
                </Badge>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              {/* Language Toggle */}
              <div className="flex items-center space-x-1 bg-white rounded-lg p-1 border">
                <Button 
                  variant={selectedLanguage === "en" ? "default" : "ghost"} 
                  size="sm"
                  onClick={() => setSelectedLanguage("en")}
                >
                  🇺🇸 EN
                </Button>
                <Button 
                  variant={selectedLanguage === "hi" ? "default" : "ghost"} 
                  size="sm"
                  onClick={() => setSelectedLanguage("hi")}
                >
                  🇮🇳 हिं
                </Button>
              </div>
              
              <Button variant="outline" size="sm">
                <Bell className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="sm">
                <Settings className="w-4 h-4" />
              </Button>
              <Avatar>
                <AvatarImage src="/placeholder.svg" />
                <AvatarFallback>SB</AvatarFallback>
              </Avatar>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Welcome Section */}
            <Card className="gradient-purple text-white border-0">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-2xl font-bold mb-2">
                      {selectedLanguage === "hi" ? "नमस्ते, आज का अध्ययन शुरू करें!" : "Welcome back! Ready to study?"}
                    </h2>
                    <p className="text-white/90 mb-4">
                      {selectedLanguage === "hi" 
                        ? "आपकी परीक्षा की तैयारी में 78% प्रगति हुई है" 
                        : "You're 78% on track with your exam preparation"}
                    </p>
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center">
                        <Clock className="w-4 h-4 mr-2" />
                        <span className="text-sm">6.5h today</span>
                      </div>
                      <div className="flex items-center">
                        <Target className="w-4 h-4 mr-2" />
                        <span className="text-sm">Goal: 8h</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-6xl opacity-80">
                    {exam.icon}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* AI Study Assistant */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Brain className="w-5 h-5 mr-2 text-primary" />
                  {selectedLanguage === "hi" ? "AI अध्ययन सहायक" : "AI Study Assistant"}
                </CardTitle>
                <CardDescription>
                  {selectedLanguage === "hi" 
                    ? "मल्टीमीडिया इनपुट के साथ सवाल पूछें और तुरंत जवाब पाएं"
                    : "Ask questions with multimedia inputs and get instant AI-powered answers"}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <div className="flex-1 relative">
                      <input 
                        type="text" 
                        placeholder={selectedLanguage === "hi" ? "अपना प्रश्न यहाँ टाइप करें..." : "Type your question here..."}
                        className="w-full p-3 border rounded-lg pr-32"
                      />
                      <div className="absolute right-2 top-1/2 transform -translate-y-1/2 flex space-x-1">
                        <Button size="sm" variant="ghost" className={isRecording ? "bg-red-100 text-red-600" : ""}>
                          <Mic className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="ghost">
                          <Upload className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="ghost">
                          <Video className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                    <Button>
                      <Search className="w-4 h-4 mr-2" />
                      {selectedLanguage === "hi" ? "खोजें" : "Ask AI"}
                    </Button>
                  </div>
                  
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="outline" className="cursor-pointer hover:bg-primary hover:text-white">
                      {selectedLanguage === "hi" ? "भौतिकी के सूत्र" : "Physics formulas"}
                    </Badge>
                    <Badge variant="outline" className="cursor-pointer hover:bg-primary hover:text-white">
                      {selectedLanguage === "hi" ? "रसायन अभिक्रिया" : "Chemical reactions"}
                    </Badge>
                    <Badge variant="outline" className="cursor-pointer hover:bg-primary hover:text-white">
                      {selectedLanguage === "hi" ? "गणित के उदाहरण" : "Math examples"}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Study Tabs */}
            <Tabs defaultValue="study" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="study">
                  {selectedLanguage === "hi" ? "अध्ययन" : "Study"}
                </TabsTrigger>
                <TabsTrigger value="practice">
                  {selectedLanguage === "hi" ? "अभ्यास" : "Practice"}
                </TabsTrigger>
                <TabsTrigger value="groups">
                  {selectedLanguage === "hi" ? "समूह" : "Groups"}
                </TabsTrigger>
                <TabsTrigger value="analytics">
                  {selectedLanguage === "hi" ? "विश्लेषण" : "Analytics"}
                </TabsTrigger>
              </TabsList>

              <TabsContent value="study" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {["Physics", "Chemistry", "Mathematics"].map((subject) => (
                    <Card key={subject} className="cursor-pointer hover:shadow-lg transition-shadow">
                      <CardContent className="p-6">
                        <div className="flex items-center justify-between mb-4">
                          <h3 className="font-semibold">{subject}</h3>
                          <Button size="sm" variant="outline">
                            <Play className="w-4 h-4" />
                          </Button>
                        </div>
                        <Progress value={Math.floor(Math.random() * 100)} className="mb-2" />
                        <p className="text-sm text-muted-foreground">
                          {Math.floor(Math.random() * 50 + 50)}% completed
                        </p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="practice" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card>
                    <CardHeader>
                      <CardTitle>Mock Tests</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <Button className="w-full">
                        <Target className="w-4 h-4 mr-2" />
                        Start Full Length Test
                      </Button>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader>
                      <CardTitle>Quick Quiz</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <Button variant="outline" className="w-full">
                        <Zap className="w-4 h-4 mr-2" />
                        15-Minute Challenge
                      </Button>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="groups" className="space-y-4">
                <div className="space-y-4">
                  {studyRooms.map((room) => (
                    <Card key={room.id}>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <div className={`w-3 h-3 rounded-full ${room.isLive ? 'bg-red-500 animate-pulse' : 'bg-gray-300'}`}></div>
                            <div>
                              <h3 className="font-semibold">{room.name}</h3>
                              <p className="text-sm text-muted-foreground">
                                {room.participants} participants • {room.difficulty}
                              </p>
                            </div>
                          </div>
                          <Button size="sm" variant={room.isLive ? "default" : "outline"}>
                            {room.isLive ? "Join Live" : "Enter Room"}
                            <ArrowRight className="w-4 h-4 ml-2" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="analytics" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card>
                    <CardHeader>
                      <CardTitle>Weekly Progress</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {weeklyProgress.map((item) => (
                          <div key={item.subject}>
                            <div className="flex justify-between text-sm mb-1">
                              <span>{item.subject}</span>
                              <span className="flex items-center">
                                {item.progress}%
                                <span className={`ml-1 text-xs ${item.change > 0 ? 'text-green-500' : 'text-red-500'}`}>
                                  ({item.change > 0 ? '+' : ''}{item.change}%)
                                </span>
                              </span>
                            </div>
                            <Progress value={item.progress} className="h-2" />
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader>
                      <CardTitle>Performance Metrics</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <span className="text-sm">Average Score</span>
                          <span className="font-semibold">84%</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm">Time per Question</span>
                          <span className="font-semibold">2.3 min</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm">Accuracy Rate</span>
                          <span className="font-semibold">91%</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Study Streak */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Award className="w-5 h-5 mr-2 text-orange-500" />
                  {selectedLanguage === "hi" ? "अध्ययन श्रृंखला" : "Study Streak"}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center">
                  <div className="text-3xl font-bold text-primary mb-2">15</div>
                  <p className="text-sm text-muted-foreground">
                    {selectedLanguage === "hi" ? "दिन लगातार" : "days in a row"}
                  </p>
                  <div className="mt-4 grid grid-cols-7 gap-1">
                    {[...Array(7)].map((_, i) => (
                      <div key={i} className={`w-6 h-6 rounded ${i < 5 ? 'bg-primary' : 'bg-gray-200'}`}></div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* AI Insights */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Brain className="w-5 h-5 mr-2 text-purple-500" />
                  {selectedLanguage === "hi" ? "AI सुझाव" : "AI Insights"}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {aiInsights.map((insight, index) => (
                    <div key={index} className="flex items-start space-x-2">
                      <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></div>
                      <p className="text-sm text-muted-foreground">{insight}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Clock className="w-5 h-5 mr-2 text-blue-500" />
                  {selectedLanguage === "hi" ? "हाल की गतिविधि" : "Recent Activity"}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {recentActivity.map((activity, index) => (
                    <div key={index} className="flex items-center space-x-3">
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                        activity.type === 'quiz' ? 'bg-green-100' :
                        activity.type === 'study' ? 'bg-blue-100' : 'bg-purple-100'
                      }`}>
                        {activity.type === 'quiz' && <Target className="w-4 h-4 text-green-600" />}
                        {activity.type === 'study' && <BookOpen className="w-4 h-4 text-blue-600" />}
                        {activity.type === 'group' && <Users className="w-4 h-4 text-purple-600" />}
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">{activity.subject}</p>
                        <p className="text-xs text-muted-foreground">
                          {activity.score && `Score: ${activity.score}%`}
                          {activity.duration && `Duration: ${activity.duration}`}
                          {activity.activity && activity.activity}
                        </p>
                        <p className="text-xs text-muted-foreground">{activity.time}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>
                  {selectedLanguage === "hi" ? "त्वरित कार्य" : "Quick Actions"}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button variant="outline" className="w-full justify-start">
                  <FileText className="w-4 h-4 mr-2" />
                  {selectedLanguage === "hi" ? "नोट्स अपलोड करें" : "Upload Notes"}
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Users className="w-4 h-4 mr-2" />
                  {selectedLanguage === "hi" ? "समूह बनाएं" : "Create Study Group"}
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Calendar className="w-4 h-4 mr-2" />
                  {selectedLanguage === "hi" ? "मॉक टेस्ट शेड्यूल करें" : "Schedule Mock Test"}
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
