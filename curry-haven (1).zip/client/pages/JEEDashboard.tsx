import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  BookOpen, 
  Brain, 
  Users, 
  BarChart3, 
  Calendar, 
  Clock, 
  Target, 
  Mic, 
  Video, 
  FileText, 
  MessageSquare, 
  Settings, 
  Bell,
  Search,
  Play,
  Upload,
  Star,
  TrendingUp,
  Award,
  Zap,
  Globe,
  ChevronRight,
  Plus,
  ArrowRight,
  CheckCircle,
  Timer,
  Calculator,
  Atom,
  Beaker,
  GraduationCap,
  BookMarked,
  Users2,
  Trophy,
  Rocket,
  TestTube,
  Sigma,
  Lightbulb,
  PenTool,
  LineChart
} from "lucide-react";

const jeeSubjects = [
  {
    id: "physics",
    name: "Physics",
    icon: "⚡",
    progress: 78,
    totalChapters: 22,
    completedChapters: 17,
    color: "from-blue-500 to-blue-700",
    bgColor: "bg-blue-50",
    textColor: "text-blue-700",
    recentTopic: "Electromagnetic Induction",
    timeSpent: "45h 30m",
    accuracy: 89
  },
  {
    id: "chemistry",
    name: "Chemistry",
    icon: "🧪",
    progress: 85,
    totalChapters: 20,
    completedChapters: 17,
    color: "from-orange-500 to-red-600",
    bgColor: "bg-orange-50",
    textColor: "text-orange-700",
    recentTopic: "Coordination Compounds",
    timeSpent: "52h 15m",
    accuracy: 92
  },
  {
    id: "mathematics",
    name: "Mathematics",
    icon: "📐",
    progress: 72,
    totalChapters: 18,
    completedChapters: 13,
    color: "from-purple-500 to-indigo-600",
    bgColor: "bg-purple-50",
    textColor: "text-purple-700",
    recentTopic: "Definite Integration",
    timeSpent: "41h 45m",
    accuracy: 86
  }
];

const recentActivity = [
  { type: "test", subject: "Physics", title: "Completed Mock Test #15", score: 92, time: "2 hours ago", icon: TestTube },
  { type: "study", subject: "Chemistry", title: "Studied Organic Reactions", duration: "1h 30m", time: "4 hours ago", icon: Beaker },
  { type: "doubt", subject: "Mathematics", title: "Asked doubt in Calculus", resolved: true, time: "6 hours ago", icon: Calculator },
  { type: "group", subject: "Physics", title: "Joined Electromagnetism session", participants: 45, time: "1 day ago", icon: Users2 }
];

const aiInsights = [
  {
    type: "weak_area",
    subject: "Physics",
    message: "Focus more on Rotational Mechanics - 23% below target accuracy",
    priority: "high",
    icon: Target
  },
  {
    type: "strength",
    subject: "Chemistry",
    message: "Excellent progress in Organic Chemistry! Keep up the momentum",
    priority: "positive",
    icon: Trophy
  },
  {
    type: "recommendation",
    subject: "Mathematics",
    message: "Schedule more practice for Coordinate Geometry this week",
    priority: "medium",
    icon: Lightbulb
  },
  {
    type: "reminder",
    subject: "General",
    message: "JEE Main Mock Test #16 scheduled for tomorrow at 2 PM",
    priority: "info",
    icon: Bell
  }
];

const studyRooms = [
  { 
    id: 1, 
    subject: "Physics",
    topic: "Electromagnetic Induction & AC Circuits", 
    participants: 234, 
    isLive: true, 
    difficulty: "Advanced",
    mentor: "Dr. Rajesh Kumar",
    timeLeft: "45 min"
  },
  { 
    id: 2, 
    subject: "Chemistry",
    topic: "Coordination Chemistry Doubt Session", 
    participants: 156, 
    isLive: true, 
    difficulty: "Intermediate",
    mentor: "Prof. Priya Sharma",
    timeLeft: "1h 20m"
  },
  { 
    id: 3, 
    subject: "Mathematics",
    topic: "Integration Techniques Workshop", 
    participants: 189, 
    isLive: false, 
    difficulty: "Advanced",
    mentor: "Mr. Arjun Singh",
    startTime: "3:00 PM"
  }
];

const quickActions = [
  { id: "mock_test", title: "Take Mock Test", icon: Timer, color: "bg-blue-500", description: "Full JEE simulation" },
  { id: "ai_doubt", title: "Ask AI Doubt", icon: Brain, color: "bg-purple-500", description: "Instant AI solutions" },
  { id: "practice_questions", title: "Practice Questions", icon: BookMarked, color: "bg-green-500", description: "Subject-wise practice" },
  { id: "study_planner", title: "Study Planner", icon: Calendar, color: "bg-orange-500", description: "Plan your week" },
  { id: "previous_papers", title: "Previous Papers", icon: FileText, color: "bg-red-500", description: "JEE 2015-2024" },
  { id: "join_group", title: "Join Study Group", icon: Users, color: "bg-indigo-500", description: "Live sessions" }
];

export default function JEEDashboard() {
  const navigate = useNavigate();
  const [selectedSubject, setSelectedSubject] = useState<string>("physics");
  const [studyStreak, setStudyStreak] = useState(15);
  const [dailyGoal, setDailyGoal] = useState({ target: 8, completed: 6.5 });

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-orange-50 to-purple-50">
      {/* Header */}
      <header className="border-b bg-white/90 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 gradient-jee-primary rounded-xl flex items-center justify-center shadow-lg">
                <GraduationCap className="w-7 h-7 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gradient-jee">JEE Master AI</h1>
                <p className="text-sm text-muted-foreground">Your Personal JEE Preparation Hub</p>
              </div>
              <Badge className="bg-gradient-to-r from-green-500 to-emerald-600 text-white border-0 font-bold ml-4">
                🔥 {studyStreak} Day Streak
              </Badge>
            </div>
            
            <div className="flex items-center space-x-4">
              <Button variant="outline" size="sm" className="border-2">
                <Bell className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="sm" className="border-2">
                <Settings className="w-4 h-4" />
              </Button>
              <Avatar className="border-2 border-primary">
                <AvatarImage src="/placeholder.svg" />
                <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-600 text-white font-bold">
                  JA
                </AvatarFallback>
              </Avatar>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-6 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <Card className="gradient-jee-primary text-white border-0 shadow-2xl">
            <CardContent className="p-8">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-3xl font-bold mb-3">Welcome back, Aspirant! 🚀</h2>
                  <p className="text-white/90 text-lg mb-4">
                    You're {Math.round((dailyGoal.completed / dailyGoal.target) * 100)}% on track with today's study goal
                  </p>
                  <div className="flex items-center space-x-6">
                    <div className="flex items-center">
                      <Clock className="w-5 h-5 mr-2" />
                      <span className="font-medium">{dailyGoal.completed}h / {dailyGoal.target}h today</span>
                    </div>
                    <div className="flex items-center">
                      <Target className="w-5 h-5 mr-2" />
                      <span className="font-medium">JEE 2025 in 156 days</span>
                    </div>
                    <div className="flex items-center">
                      <Trophy className="w-5 h-5 mr-2" />
                      <span className="font-medium">Rank Goal: AIR 200</span>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-6xl opacity-80 mb-2">🎯</div>
                  <Progress value={(dailyGoal.completed / dailyGoal.target) * 100} className="w-32 h-3" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Subject Progress */}
            <Card className="shadow-2xl border-0">
              <CardHeader>
                <CardTitle className="text-2xl font-bold flex items-center">
                  <BookOpen className="w-6 h-6 mr-3 text-primary" />
                  JEE Subject Progress
                </CardTitle>
                <CardDescription className="text-base">
                  Track your preparation across Physics, Chemistry, and Mathematics
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {jeeSubjects.map((subject) => (
                    <Card 
                      key={subject.id}
                      className={`cursor-pointer transition-all duration-300 hover:shadow-lg border-2 ${
                        selectedSubject === subject.id ? 'ring-2 ring-primary shadow-lg' : ''
                      }`}
                      onClick={() => setSelectedSubject(subject.id)}
                    >
                      <CardContent className="p-6">
                        <div className="flex items-center justify-between mb-4">
                          <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-2xl bg-gradient-to-br ${subject.color} shadow-lg`}>
                            {subject.icon}
                          </div>
                          <Badge className={`${subject.bgColor} ${subject.textColor} border-0 font-bold`}>
                            {subject.accuracy}% accuracy
                          </Badge>
                        </div>
                        
                        <h3 className="font-bold text-lg mb-2">{subject.name}</h3>
                        <div className="space-y-3">
                          <div>
                            <div className="flex justify-between text-sm mb-1">
                              <span>Progress</span>
                              <span className="font-bold">{subject.progress}%</span>
                            </div>
                            <Progress value={subject.progress} className="h-2" />
                          </div>
                          
                          <div className="text-sm space-y-1">
                            <div className="flex justify-between">
                              <span>Chapters:</span>
                              <span className="font-bold">{subject.completedChapters}/{subject.totalChapters}</span>
                            </div>
                            <div className="flex justify-between">
                              <span>Time Spent:</span>
                              <span className="font-bold">{subject.timeSpent}</span>
                            </div>
                            <div className="text-xs text-muted-foreground">
                              Recent: {subject.recentTopic}
                            </div>
                          </div>
                          
                          <Button 
                            className={`w-full bg-gradient-to-r ${subject.color} text-white border-0 font-medium`}
                            onClick={() => navigate(`/study/${subject.id}`)}
                          >
                            Continue Studying
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="shadow-2xl border-0">
              <CardHeader>
                <CardTitle className="text-2xl font-bold flex items-center">
                  <Zap className="w-6 h-6 mr-3 text-primary" />
                  Quick Actions
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {quickActions.map((action) => (
                    <Card key={action.id} className="cursor-pointer hover:shadow-lg transition-all duration-300 border-2 hover:border-primary/30">
                      <CardContent className="p-4 text-center">
                        <div className={`w-12 h-12 ${action.color} rounded-xl flex items-center justify-center mx-auto mb-3 shadow-lg`}>
                          <action.icon className="w-6 h-6 text-white" />
                        </div>
                        <h3 className="font-bold text-sm mb-1">{action.title}</h3>
                        <p className="text-xs text-muted-foreground">{action.description}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* AI Study Assistant */}
            <Card className="shadow-2xl border-0">
              <CardHeader>
                <CardTitle className="text-2xl font-bold flex items-center">
                  <Brain className="w-6 h-6 mr-3 text-primary" />
                  AI JEE Tutor
                </CardTitle>
                <CardDescription className="text-base">
                  Ask any JEE question and get instant AI-powered solutions
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <div className="flex-1 relative">
                      <input 
                        type="text" 
                        placeholder="Ask any JEE Physics, Chemistry, or Math question..."
                        className="w-full p-4 border-2 rounded-xl pr-32 text-lg"
                      />
                      <div className="absolute right-3 top-1/2 transform -translate-y-1/2 flex space-x-2">
                        <Button size="sm" variant="ghost">
                          <Mic className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="ghost">
                          <Upload className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="ghost">
                          <Video className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                    <Button className="gradient-jee-primary text-white border-0 px-6 py-4">
                      <Search className="w-5 h-5 mr-2" />
                      Ask AI
                    </Button>
                  </div>
                  
                  <div className="flex flex-wrap gap-2">
                    {[
                      "Explain electromagnetic induction",
                      "Organic reaction mechanisms",
                      "Integration by parts formula",
                      "JEE previous year solutions"
                    ].map((suggestion, index) => (
                      <Badge 
                        key={index}
                        variant="outline" 
                        className="cursor-pointer hover:bg-primary hover:text-white transition-all px-3 py-1"
                      >
                        {suggestion}
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Live Study Rooms */}
            <Card className="shadow-2xl border-0">
              <CardHeader>
                <CardTitle className="text-2xl font-bold flex items-center">
                  <Users className="w-6 h-6 mr-3 text-primary" />
                  Live JEE Study Rooms
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {studyRooms.map((room) => (
                    <Card key={room.id} className="border-2">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-4">
                            <div className={`w-4 h-4 rounded-full ${room.isLive ? 'bg-red-500 animate-pulse' : 'bg-gray-300'}`}></div>
                            <div>
                              <h3 className="font-bold text-lg">{room.topic}</h3>
                              <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                                <span>📚 {room.subject}</span>
                                <span>👨‍🏫 {room.mentor}</span>
                                <span>👥 {room.participants} students</span>
                                <Badge className="bg-yellow-100 text-yellow-700 border-0">
                                  {room.difficulty}
                                </Badge>
                              </div>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="text-sm text-muted-foreground mb-2">
                              {room.isLive ? `${room.timeLeft} left` : `Starts at ${room.startTime}`}
                            </div>
                            <Button 
                              className={room.isLive ? "gradient-jee-primary text-white border-0" : ""}
                              variant={room.isLive ? "default" : "outline"}
                            >
                              {room.isLive ? "Join Live" : "Set Reminder"}
                              <ArrowRight className="w-4 h-4 ml-2" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Study Streak */}
            <Card className="shadow-2xl border-0">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Award className="w-5 h-5 mr-2 text-orange-500" />
                  Study Streak
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center">
                  <div className="text-4xl font-bold text-gradient-jee mb-2">{studyStreak}</div>
                  <p className="text-sm text-muted-foreground mb-4">days in a row</p>
                  <div className="grid grid-cols-7 gap-1 mb-4">
                    {[...Array(7)].map((_, i) => (
                      <div 
                        key={i} 
                        className={`w-6 h-6 rounded ${i < 6 ? 'bg-gradient-to-br from-green-400 to-emerald-500' : 'bg-gray-200'}`}
                      ></div>
                    ))}
                  </div>
                  <p className="text-xs text-muted-foreground">Study today to maintain your streak!</p>
                </div>
              </CardContent>
            </Card>

            {/* AI Insights */}
            <Card className="shadow-2xl border-0">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Brain className="w-5 h-5 mr-2 text-purple-500" />
                  AI Insights
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {aiInsights.map((insight, index) => (
                    <div key={index} className="flex items-start space-x-3">
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${
                        insight.priority === 'high' ? 'bg-red-100' :
                        insight.priority === 'positive' ? 'bg-green-100' :
                        insight.priority === 'medium' ? 'bg-yellow-100' : 'bg-blue-100'
                      }`}>
                        <insight.icon className={`w-4 h-4 ${
                          insight.priority === 'high' ? 'text-red-600' :
                          insight.priority === 'positive' ? 'text-green-600' :
                          insight.priority === 'medium' ? 'text-yellow-600' : 'text-blue-600'
                        }`} />
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">{insight.message}</p>
                        <Badge variant="outline" className="mt-1 text-xs">
                          {insight.subject}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card className="shadow-2xl border-0">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Clock className="w-5 h-5 mr-2 text-blue-500" />
                  Recent Activity
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentActivity.map((activity, index) => (
                    <div key={index} className="flex items-center space-x-3">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                        activity.type === 'test' ? 'bg-green-100' :
                        activity.type === 'study' ? 'bg-blue-100' :
                        activity.type === 'doubt' ? 'bg-purple-100' : 'bg-orange-100'
                      }`}>
                        <activity.icon className={`w-5 h-5 ${
                          activity.type === 'test' ? 'text-green-600' :
                          activity.type === 'study' ? 'text-blue-600' :
                          activity.type === 'doubt' ? 'text-purple-600' : 'text-orange-600'
                        }`} />
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">{activity.title}</p>
                        <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                          <span>{activity.subject}</span>
                          <span>•</span>
                          <span>{activity.time}</span>
                        </div>
                        {activity.score && (
                          <Badge className="bg-green-100 text-green-700 border-0 mt-1">
                            Score: {activity.score}%
                          </Badge>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Performance Stats */}
            <Card className="shadow-2xl border-0">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <LineChart className="w-5 h-5 mr-2 text-green-500" />
                  This Week
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-3 bg-blue-50 rounded-xl">
                    <div className="text-2xl font-bold text-blue-600">32h</div>
                    <div className="text-xs text-blue-700">Study Time</div>
                  </div>
                  <div className="text-center p-3 bg-green-50 rounded-xl">
                    <div className="text-2xl font-bold text-green-600">91%</div>
                    <div className="text-xs text-green-700">Avg Score</div>
                  </div>
                </div>
                
                <div className="text-center p-3 bg-purple-50 rounded-xl">
                  <div className="text-xl font-bold text-purple-600">AIR 245</div>
                  <div className="text-xs text-purple-700">Predicted Rank</div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
