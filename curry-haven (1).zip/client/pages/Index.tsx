import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  BookOpen, 
  Users, 
  Brain, 
  Trophy, 
  Globe, 
  Mic,
  Video,
  FileText,
  MessageSquare,
  BarChart3,
  Zap,
  Star,
  CheckCircle,
  PlayCircle,
  ArrowRight,
  Target,
  Clock,
  TrendingUp,
  Shield,
  Calculator,
  Atom,
  Beaker,
  Lightbulb,
  Award,
  Timer,
  Users2,
  BookMarked,
  GraduationCap,
  Rocket
} from "lucide-react";

const jeeSubjects = [
  { 
    id: "physics", 
    name: "Physics", 
    icon: "⚡", 
    color: "from-blue-500 to-blue-700",
    bgColor: "bg-blue-50",
    textColor: "text-blue-700",
    description: "Master mechanics, thermodynamics, optics, and modern physics",
    topics: ["Mechanics", "Thermodynamics", "Waves & Optics", "Modern Physics"],
    weightage: "33%"
  },
  { 
    id: "chemistry", 
    name: "Chemistry", 
    icon: "🧪", 
    color: "from-orange-500 to-red-600",
    bgColor: "bg-orange-50",
    textColor: "text-orange-700",
    description: "Explore organic, inorganic, and physical chemistry concepts",
    topics: ["Organic Chemistry", "Inorganic Chemistry", "Physical Chemistry"],
    weightage: "33%"
  },
  { 
    id: "mathematics", 
    name: "Mathematics", 
    icon: "📐", 
    color: "from-purple-500 to-indigo-600",
    bgColor: "bg-purple-50",
    textColor: "text-purple-700",
    description: "Solve complex problems in calculus, algebra, and geometry",
    topics: ["Calculus", "Algebra", "Coordinate Geometry", "Trigonometry"],
    weightage: "34%"
  }
];

const jeeFeatures = [
  {
    icon: Brain,
    title: "AI-Powered JEE Tutor",
    description: "Get instant solutions to JEE problems with step-by-step explanations",
    color: "text-blue-600",
    bgColor: "bg-blue-50"
  },
  {
    icon: Users,
    title: "JEE Study Groups",
    description: "Join live study sessions with fellow JEE aspirants",
    color: "text-orange-600",
    bgColor: "bg-orange-50"
  },
  {
    icon: BarChart3,
    title: "JEE Progress Analytics",
    description: "Track your preparation with detailed performance insights",
    color: "text-purple-600",
    bgColor: "bg-purple-50"
  },
  {
    icon: BookMarked,
    title: "Previous Year Papers",
    description: "Practice with authentic JEE Main & Advanced question papers",
    color: "text-green-600",
    bgColor: "bg-green-50"
  },
  {
    icon: Timer,
    title: "Mock Tests",
    description: "Simulate real JEE exam conditions with timed assessments",
    color: "text-red-600",
    bgColor: "bg-red-50"
  },
  {
    icon: Target,
    title: "Personalized Study Plan",
    description: "AI-generated study schedules tailored for JEE success",
    color: "text-indigo-600",
    bgColor: "bg-indigo-50"
  }
];

const jeeSuccessStories = [
  {
    name: "Arjun Mehta",
    rank: "AIR 12",
    image: "/placeholder.svg",
    quote: "The AI tutor helped me understand complex physics concepts that I struggled with for months!",
    year: "JEE Advanced 2024",
    college: "IIT Bombay - Computer Science"
  },
  {
    name: "Priya Sharma",
    rank: "AIR 89",
    image: "/placeholder.svg",
    quote: "Group study sessions were a game-changer. Discussing problems with peers boosted my confidence.",
    year: "JEE Advanced 2024",
    college: "IIT Delhi - Mechanical Engineering"
  },
  {
    name: "Karan Singh",
    rank: "AIR 156",
    image: "/placeholder.svg",
    quote: "The personalized study plan kept me on track. I never felt overwhelmed with my preparation.",
    year: "JEE Advanced 2024",
    college: "IIT Kanpur - Electrical Engineering"
  }
];

const jeeStats = [
  { label: "JEE Aspirants", value: "2.1M+", icon: Users2 },
  { label: "Success Rate", value: "98.5%", icon: Trophy },
  { label: "AI Solutions", value: "50K+", icon: Brain },
  { label: "Study Hours", value: "1M+", icon: Clock }
];

export default function Index() {
  const navigate = useNavigate();
  const [selectedSubject, setSelectedSubject] = useState<string | null>(null);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-orange-50 to-purple-50">
      {/* Header */}
      <header className="border-b bg-white/90 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 gradient-jee-primary rounded-xl flex items-center justify-center shadow-lg">
                <GraduationCap className="w-7 h-7 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gradient-jee">JEE Master AI</h1>
                <p className="text-sm text-muted-foreground">Your AI-Powered JEE Companion</p>
              </div>
            </div>
            <nav className="hidden md:flex items-center space-x-6">
              <a href="#subjects" className="text-sm font-medium hover:text-primary transition-colors">Subjects</a>
              <a href="#features" className="text-sm font-medium hover:text-primary transition-colors">Features</a>
              <a href="#success" className="text-sm font-medium hover:text-primary transition-colors">Success Stories</a>
              <Button variant="outline" size="sm" className="font-medium">Sign In</Button>
              <Button size="sm" className="gradient-jee-primary text-white border-0 font-medium">
                Start Preparation
              </Button>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-6">
        <div className="container mx-auto text-center max-w-5xl">
          <Badge className="mb-6 bg-gradient-to-r from-blue-500 to-purple-600 text-white border-0 text-sm px-4 py-2">
            🚀 India's #1 AI-Powered JEE Platform
          </Badge>
          <h1 className="text-6xl md:text-7xl font-bold mb-6 text-gradient-jee leading-tight">
            Crack JEE with
            <br />
            <span className="bg-gradient-to-r from-blue-600 via-orange-500 to-purple-600 bg-clip-text text-transparent">
              AI Intelligence
            </span>
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto leading-relaxed">
            Join thousands of successful JEE aspirants using our revolutionary AI platform. 
            Master Physics, Chemistry & Mathematics with personalized learning, live group sessions, and intelligent doubt solving.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Button 
              size="lg" 
              className="text-lg px-10 py-7 gradient-jee-primary text-white border-0 shadow-xl hover:shadow-2xl transform hover:scale-105 transition-all"
              onClick={() => navigate('/dashboard')}
            >
              <Rocket className="w-6 h-6 mr-3" />
              Start JEE Preparation
              <ArrowRight className="w-5 h-5 ml-3" />
            </Button>
            <Button 
              variant="outline" 
              size="lg" 
              className="text-lg px-10 py-7 border-2 border-primary hover:bg-primary hover:text-white transition-all"
            >
              <PlayCircle className="w-6 h-6 mr-3" />
              Watch Demo
            </Button>
          </div>
          
          {/* Quick Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-3xl mx-auto">
            {jeeStats.map((stat, index) => (
              <div key={index} className="text-center p-4 bg-white/70 backdrop-blur-sm rounded-2xl shadow-lg">
                <stat.icon className="w-8 h-8 mx-auto mb-2 text-primary" />
                <div className="text-3xl font-bold text-gradient-jee">{stat.value}</div>
                <div className="text-sm text-muted-foreground font-medium">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* JEE Subjects Section */}
      <section id="subjects" className="py-20 px-6 bg-white">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-6 text-gradient-jee">Master JEE Subjects</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Comprehensive preparation for Physics, Chemistry, and Mathematics with AI-powered personalized learning
            </p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {jeeSubjects.map((subject) => (
              <Card 
                key={subject.id}
                className={`cursor-pointer transition-all duration-500 hover:shadow-2xl hover:scale-105 border-2 ${
                  selectedSubject === subject.id ? 'ring-4 ring-primary/30 shadow-2xl scale-105' : 'hover:border-primary/30'
                }`}
                onClick={() => setSelectedSubject(subject.id)}
              >
                <CardHeader className="pb-4">
                  <div className="flex items-center justify-between mb-4">
                    <div className={`w-16 h-16 rounded-2xl flex items-center justify-center text-3xl bg-gradient-to-br ${subject.color} shadow-lg`}>
                      {subject.icon}
                    </div>
                    <div className="text-right">
                      <Badge className={`${subject.bgColor} ${subject.textColor} border-0 font-bold`}>
                        {subject.weightage} weightage
                      </Badge>
                    </div>
                  </div>
                  <CardTitle className="text-2xl font-bold">{subject.name}</CardTitle>
                  <CardDescription className="text-base leading-relaxed">
                    {subject.description}
                  </CardDescription>
                </CardHeader>
                
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-semibold mb-3 text-lg">Key Topics:</h4>
                      <div className="grid grid-cols-2 gap-2">
                        {subject.topics.map((topic, index) => (
                          <div key={index} className="flex items-center text-sm">
                            <CheckCircle className="w-4 h-4 mr-2 text-green-500" />
                            <span>{topic}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    <div className="pt-4">
                      <Button 
                        className={`w-full bg-gradient-to-r ${subject.color} text-white border-0 font-medium hover:shadow-lg transition-all`}
                        onClick={() => navigate(`/study/${subject.id}`)}
                      >
                        Start {subject.name} Preparation
                        <ArrowRight className="w-4 h-4 ml-2" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 px-6 bg-gradient-to-br from-blue-50 to-purple-50">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-6 text-gradient-jee">Powerful JEE Features</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Everything you need to excel in JEE Main & Advanced, powered by cutting-edge AI technology
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {jeeFeatures.map((feature, index) => (
              <Card key={index} className="group hover:shadow-2xl transition-all duration-500 border-0 bg-white/80 backdrop-blur-sm hover:scale-105">
                <CardHeader className="pb-4">
                  <div className={`w-16 h-16 rounded-2xl ${feature.bgColor} flex items-center justify-center group-hover:scale-110 transition-transform duration-300 shadow-lg`}>
                    <feature.icon className={`w-8 h-8 ${feature.color}`} />
                  </div>
                  <CardTitle className="text-xl font-bold">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base leading-relaxed">
                    {feature.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Live Study Session Preview */}
      <section className="py-20 px-6 bg-white">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-6 text-gradient-jee">Live JEE Study Sessions</h2>
            <p className="text-xl text-muted-foreground">Join thousands of JEE aspirants in real-time collaborative learning</p>
          </div>
          
          <div className="max-w-5xl mx-auto">
            <Card className="p-8 shadow-2xl border-0 bg-gradient-to-br from-white to-blue-50">
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center space-x-4">
                  <div className="w-4 h-4 bg-red-500 rounded-full animate-pulse shadow-lg"></div>
                  <span className="font-bold text-xl">Live: JEE Physics - Electromagnetism</span>
                  <Badge className="bg-green-100 text-green-700 border-0 font-bold">
                    🔥 456 students online
                  </Badge>
                </div>
                <div className="flex space-x-3">
                  <Button variant="outline" size="sm" className="border-2">
                    <Mic className="w-4 h-4" />
                  </Button>
                  <Button variant="outline" size="sm" className="border-2">
                    <MessageSquare className="w-4 h-4" />
                  </Button>
                  <Button variant="outline" size="sm" className="border-2">
                    <Video className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
                <div className="lg:col-span-3">
                  <div className="bg-gradient-to-br from-blue-100 to-purple-100 rounded-2xl p-12 h-80 flex items-center justify-center shadow-inner">
                    <div className="text-center">
                      <div className="w-24 h-24 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-6 shadow-xl">
                        <PlayCircle className="w-12 h-12 text-white" />
                      </div>
                      <h3 className="text-2xl font-bold text-gradient-jee mb-2">Interactive AI Whiteboard</h3>
                      <p className="text-muted-foreground text-lg">Solve JEE problems together with AI assistance</p>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div className="text-sm font-bold text-muted-foreground">ACTIVE PARTICIPANTS</div>
                  <div className="space-y-3">
                    {[
                      { name: "Rahul K.", status: "asking doubt", color: "bg-blue-500" },
                      { name: "Priya S.", status: "solving problem", color: "bg-green-500" },
                      { name: "Arjun M.", status: "taking notes", color: "bg-purple-500" },
                      { name: "Sneha G.", status: "active", color: "bg-orange-500" },
                      { name: "Karan T.", status: "active", color: "bg-red-500" }
                    ].map((participant, i) => (
                      <div key={i} className="flex items-center space-x-3">
                        <div className={`w-10 h-10 ${participant.color} rounded-full flex items-center justify-center shadow-lg`}>
                          <span className="text-white font-bold text-sm">{participant.name.charAt(0)}</span>
                        </div>
                        <div>
                          <div className="font-medium text-sm">{participant.name}</div>
                          <div className="text-xs text-muted-foreground">{participant.status}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  <Button className="w-full gradient-jee-primary text-white border-0 font-bold shadow-lg hover:shadow-xl transition-all">
                    Join Live Session
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Progress Dashboard Preview */}
      <section className="py-20 px-6 bg-gradient-to-br from-orange-50 to-red-50">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-6 text-gradient-jee">AI-Powered JEE Analytics</h2>
            <p className="text-xl text-muted-foreground">Real-time insights to optimize your JEE preparation strategy</p>
          </div>
          
          <div className="max-w-5xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-8">
            <Card className="lg:col-span-2 p-8 shadow-2xl border-0">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-2xl font-bold">Weekly JEE Progress</h3>
                <Badge className="bg-green-100 text-green-700 border-0 font-bold text-lg px-3 py-1">
                  +15% this week 📈
                </Badge>
              </div>
              <div className="space-y-6">
                {jeeSubjects.map((subject, index) => {
                  const progress = [78, 85, 72][index];
                  const change = [+5, +2, +8][index];
                  return (
                    <div key={subject.id}>
                      <div className="flex justify-between text-lg mb-3">
                        <span className="font-bold flex items-center">
                          <span className="text-2xl mr-3">{subject.icon}</span>
                          {subject.name}
                        </span>
                        <span className="flex items-center font-bold">
                          {progress}%
                          <span className={`ml-2 text-sm ${change > 0 ? 'text-green-600' : 'text-red-600'}`}>
                            ({change > 0 ? '+' : ''}{change}%)
                          </span>
                        </span>
                      </div>
                      <Progress value={progress} className="h-3 shadow-inner" />
                    </div>
                  );
                })}
              </div>
            </Card>
            
            <div className="space-y-6">
              <Card className="p-6 shadow-2xl border-0">
                <div className="flex items-center space-x-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-700 rounded-2xl flex items-center justify-center shadow-lg">
                    <Clock className="w-8 h-8 text-white" />
                  </div>
                  <div>
                    <p className="font-bold text-lg">Study Time</p>
                    <p className="text-3xl font-bold text-blue-600">7.5h</p>
                    <p className="text-sm text-muted-foreground font-medium">Today</p>
                  </div>
                </div>
              </Card>
              
              <Card className="p-6 shadow-2xl border-0">
                <div className="flex items-center space-x-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-green-700 rounded-2xl flex items-center justify-center shadow-lg">
                    <TrendingUp className="w-8 h-8 text-white" />
                  </div>
                  <div>
                    <p className="font-bold text-lg">JEE Score</p>
                    <p className="text-3xl font-bold text-green-600">94%</p>
                    <p className="text-sm text-muted-foreground font-medium">Last Mock Test</p>
                  </div>
                </div>
              </Card>

              <Card className="p-6 shadow-2xl border-0">
                <div className="flex items-center space-x-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-700 rounded-2xl flex items-center justify-center shadow-lg">
                    <Target className="w-8 h-8 text-white" />
                  </div>
                  <div>
                    <p className="font-bold text-lg">Rank Prediction</p>
                    <p className="text-3xl font-bold text-purple-600">AIR 245</p>
                    <p className="text-sm text-muted-foreground font-medium">Based on current performance</p>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Success Stories */}
      <section id="success" className="py-20 px-6 bg-white">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-6 text-gradient-jee">JEE Success Stories</h2>
            <p className="text-xl text-muted-foreground">See how JEE Master AI helped students achieve their IIT dreams</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {jeeSuccessStories.map((story, index) => (
              <Card key={index} className="p-8 shadow-2xl border-0 hover:scale-105 transition-all duration-300">
                <div className="flex items-center space-x-4 mb-6">
                  <Avatar className="w-16 h-16 border-4 border-primary/20">
                    <AvatarImage src={story.image} />
                    <AvatarFallback className="text-xl font-bold bg-gradient-to-br from-blue-500 to-purple-600 text-white">
                      {story.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-bold text-lg">{story.name}</p>
                    <p className="text-sm text-muted-foreground">{story.year}</p>
                  </div>
                </div>
                
                <div className="flex mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                
                <p className="text-muted-foreground mb-6 leading-relaxed">"{story.quote}"</p>
                
                <div className="space-y-2">
                  <Badge className="bg-gradient-to-r from-blue-500 to-purple-600 text-white border-0 font-bold text-lg px-4 py-2">
                    🏆 {story.rank}
                  </Badge>
                  <p className="text-sm font-bold text-green-600">{story.college}</p>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 px-6 bg-gradient-to-r from-blue-600 via-purple-600 to-orange-600">
        <div className="container mx-auto text-center">
          <h2 className="text-5xl font-bold text-white mb-8">
            Ready to Crack JEE 2025?
          </h2>
          <p className="text-2xl text-white/90 mb-12 max-w-3xl mx-auto leading-relaxed">
            Join thousands of successful JEE aspirants and start your AI-powered preparation journey today
          </p>
          
          <div className="flex flex-col sm:flex-row gap-6 justify-center mb-8">
            <Button 
              size="lg" 
              variant="secondary" 
              className="text-xl px-12 py-8 bg-white text-primary hover:bg-gray-100 border-0 shadow-2xl font-bold"
              onClick={() => navigate('/dashboard')}
            >
              <Zap className="w-6 h-6 mr-3" />
              Start Free Trial - 15 Days
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="text-xl px-12 py-8 text-white border-2 border-white hover:bg-white hover:text-primary transition-all font-bold"
            >
              <Video className="w-6 h-6 mr-3" />
              Book Demo Call
            </Button>
          </div>
          
          <div className="flex flex-wrap justify-center gap-6 text-white/80 text-lg font-medium">
            <div className="flex items-center">
              <CheckCircle className="w-5 h-5 mr-2" />
              No Credit Card Required
            </div>
            <div className="flex items-center">
              <CheckCircle className="w-5 h-5 mr-2" />
              Cancel Anytime
            </div>
            <div className="flex items-center">
              <CheckCircle className="w-5 h-5 mr-2" />
              Money-Back Guarantee
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16 px-6">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="md:col-span-2">
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-12 h-12 gradient-jee-primary rounded-xl flex items-center justify-center shadow-lg">
                  <GraduationCap className="w-7 h-7 text-white" />
                </div>
                <span className="text-2xl font-bold">JEE Master AI</span>
              </div>
              <p className="text-gray-400 text-lg leading-relaxed mb-6">
                Empowering JEE aspirants to achieve their IIT dreams through AI-powered learning and collaboration.
              </p>
              <div className="flex space-x-4">
                <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center cursor-pointer hover:bg-blue-700 transition-colors">
                  <span className="text-white font-bold">f</span>
                </div>
                <div className="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center cursor-pointer hover:bg-blue-600 transition-colors">
                  <span className="text-white font-bold">t</span>
                </div>
                <div className="w-10 h-10 bg-purple-600 rounded-lg flex items-center justify-center cursor-pointer hover:bg-purple-700 transition-colors">
                  <span className="text-white font-bold">i</span>
                </div>
              </div>
            </div>
            
            <div>
              <h3 className="font-bold text-lg mb-6">JEE Subjects</h3>
              <div className="space-y-3 text-gray-400">
                <div className="hover:text-white transition-colors cursor-pointer">Physics</div>
                <div className="hover:text-white transition-colors cursor-pointer">Chemistry</div>
                <div className="hover:text-white transition-colors cursor-pointer">Mathematics</div>
                <div className="hover:text-white transition-colors cursor-pointer">Previous Year Papers</div>
              </div>
            </div>
            
            <div>
              <h3 className="font-bold text-lg mb-6">Company</h3>
              <div className="space-y-3 text-gray-400">
                <div className="hover:text-white transition-colors cursor-pointer">About Us</div>
                <div className="hover:text-white transition-colors cursor-pointer">Contact</div>
                <div className="hover:text-white transition-colors cursor-pointer">Privacy Policy</div>
                <div className="hover:text-white transition-colors cursor-pointer">Terms of Service</div>
              </div>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400">
            <p className="text-lg">© 2024 JEE Master AI. All rights reserved. Built for JEE aspirants, by education experts.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
