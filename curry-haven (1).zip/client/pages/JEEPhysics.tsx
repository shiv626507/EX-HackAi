import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  BookOpen, 
  Brain, 
  Clock, 
  Target, 
  Play, 
  CheckCircle,
  ArrowRight,
  Zap,
  GraduationCap,
  Award,
  Users,
  Timer,
  BookMarked,
  Lightbulb,
  Calculator,
  FileText,
  Video,
  Volume2,
  Star,
  ChevronRight,
  BarChart3,
  TrendingUp
} from "lucide-react";

const physicsChapters = [
  {
    id: "kinematics",
    title: "Kinematics",
    progress: 95,
    difficulty: "Easy",
    timeRequired: "8-10 hours",
    importance: "High",
    topics: ["Motion in One Dimension", "Motion in Two Dimensions", "Projectile Motion", "Relative Motion"],
    questionsCount: 45,
    videoLectures: 12,
    completed: true
  },
  {
    id: "laws-of-motion",
    title: "Laws of Motion",
    progress: 87,
    difficulty: "Medium",
    timeRequired: "10-12 hours",
    importance: "High",
    topics: ["Newton's Laws", "Friction", "Circular Motion", "Work and Energy"],
    questionsCount: 52,
    videoLectures: 15,
    completed: false
  },
  {
    id: "electromagnetic-induction",
    title: "Electromagnetic Induction",
    progress: 72,
    difficulty: "Hard",
    timeRequired: "15-18 hours",
    importance: "Very High",
    topics: ["Faraday's Law", "Lenz's Law", "Self & Mutual Inductance", "AC Circuits"],
    questionsCount: 68,
    videoLectures: 20,
    completed: false
  },
  {
    id: "thermodynamics",
    title: "Thermodynamics",
    progress: 60,
    difficulty: "Hard",
    timeRequired: "12-15 hours",
    importance: "High",
    topics: ["First Law", "Second Law", "Heat Engines", "Entropy"],
    questionsCount: 58,
    videoLectures: 18,
    completed: false
  },
  {
    id: "waves-and-optics",
    title: "Waves and Optics",
    progress: 45,
    difficulty: "Medium",
    timeRequired: "14-16 hours",
    importance: "High",
    topics: ["Wave Motion", "Sound Waves", "Light Waves", "Interference", "Diffraction"],
    questionsCount: 72,
    videoLectures: 22,
    completed: false
  },
  {
    id: "modern-physics",
    title: "Modern Physics",
    progress: 30,
    difficulty: "Hard",
    timeRequired: "16-20 hours",
    importance: "Very High",
    topics: ["Photoelectric Effect", "Atomic Structure", "Nuclear Physics", "Semiconductor"],
    questionsCount: 65,
    videoLectures: 25,
    completed: false
  }
];

const recentSolvedQuestions = [
  {
    id: 1,
    question: "A particle moves with constant acceleration...",
    topic: "Kinematics",
    difficulty: "Medium",
    solved: true,
    timeSpent: "4 min",
    accuracy: 100
  },
  {
    id: 2,
    question: "Calculate the magnetic flux through a coil...",
    topic: "Electromagnetic Induction",
    difficulty: "Hard",
    solved: true,
    timeSpent: "7 min",
    accuracy: 85
  },
  {
    id: 3,
    question: "Find the efficiency of a Carnot engine...",
    topic: "Thermodynamics",
    difficulty: "Medium",
    solved: false,
    timeSpent: "5 min",
    accuracy: 0
  }
];

const physicsFormulas = [
  { topic: "Kinematics", formula: "v = u + at", description: "First equation of motion" },
  { topic: "Newton's Laws", formula: "F = ma", description: "Second law of motion" },
  { topic: "Energy", formula: "E = ½mv²", description: "Kinetic energy" },
  { topic: "Electromagnetic", formula: "ε = -dΦ/dt", description: "Faraday's law" }
];

export default function JEEPhysics() {
  const navigate = useNavigate();
  const [selectedChapter, setSelectedChapter] = useState<string>("electromagnetic-induction");

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Easy": return "bg-green-100 text-green-700";
      case "Medium": return "bg-yellow-100 text-yellow-700";
      case "Hard": return "bg-red-100 text-red-700";
      default: return "bg-gray-100 text-gray-700";
    }
  };

  const getImportanceColor = (importance: string) => {
    switch (importance) {
      case "Very High": return "bg-red-500";
      case "High": return "bg-orange-500";
      case "Medium": return "bg-yellow-500";
      default: return "bg-gray-500";
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      {/* Header */}
      <header className="border-b bg-white/90 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button variant="outline" onClick={() => navigate("/dashboard")}>
                ← Back to Dashboard
              </Button>
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-700 rounded-xl flex items-center justify-center shadow-lg">
                  <span className="text-2xl">⚡</span>
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-gradient-jee">JEE Physics</h1>
                  <p className="text-sm text-muted-foreground">Master the fundamental laws of nature</p>
                </div>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <Badge className="bg-blue-100 text-blue-700 border-0 font-bold px-4 py-2">
                Overall Progress: 68%
              </Badge>
              <Button className="gradient-jee-primary text-white border-0">
                <Timer className="w-4 h-4 mr-2" />
                Take Mock Test
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-6 py-8">
        {/* Progress Overview */}
        <Card className="mb-8 shadow-2xl border-0">
          <CardContent className="p-8">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-700 rounded-full flex items-center justify-center mx-auto mb-3 shadow-lg">
                  <BookOpen className="w-8 h-8 text-white" />
                </div>
                <div className="text-3xl font-bold text-blue-600">6/6</div>
                <div className="text-sm text-muted-foreground">Chapters</div>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-green-700 rounded-full flex items-center justify-center mx-auto mb-3 shadow-lg">
                  <Target className="w-8 h-8 text-white" />
                </div>
                <div className="text-3xl font-bold text-green-600">320</div>
                <div className="text-sm text-muted-foreground">Questions Solved</div>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-700 rounded-full flex items-center justify-center mx-auto mb-3 shadow-lg">
                  <Clock className="w-8 h-8 text-white" />
                </div>
                <div className="text-3xl font-bold text-purple-600">45h</div>
                <div className="text-sm text-muted-foreground">Study Time</div>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-orange-500 to-red-500 rounded-full flex items-center justify-center mx-auto mb-3 shadow-lg">
                  <Award className="w-8 h-8 text-white" />
                </div>
                <div className="text-3xl font-bold text-orange-600">89%</div>
                <div className="text-sm text-muted-foreground">Accuracy</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Chapters List */}
            <Card className="shadow-2xl border-0">
              <CardHeader>
                <CardTitle className="text-2xl font-bold flex items-center">
                  <BookMarked className="w-6 h-6 mr-3 text-blue-600" />
                  Physics Chapters
                </CardTitle>
                <CardDescription className="text-base">
                  Master each chapter with comprehensive study materials and practice
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {physicsChapters.map((chapter) => (
                    <Card 
                      key={chapter.id}
                      className={`cursor-pointer transition-all duration-300 hover:shadow-lg border-2 ${
                        selectedChapter === chapter.id ? 'ring-2 ring-blue-500 shadow-lg' : ''
                      }`}
                      onClick={() => setSelectedChapter(chapter.id)}
                    >
                      <CardContent className="p-6">
                        <div className="flex items-center justify-between mb-4">
                          <div className="flex items-center space-x-3">
                            {chapter.completed ? (
                              <CheckCircle className="w-6 h-6 text-green-500" />
                            ) : (
                              <div className="w-6 h-6 border-2 border-gray-300 rounded-full"></div>
                            )}
                            <h3 className="text-xl font-bold">{chapter.title}</h3>
                          </div>
                          <div className="flex items-center space-x-2">
                            <div className={`w-3 h-3 rounded-full ${getImportanceColor(chapter.importance)}`}></div>
                            <Badge className={getDifficultyColor(chapter.difficulty)}>
                              {chapter.difficulty}
                            </Badge>
                          </div>
                        </div>
                        
                        <div className="space-y-3">
                          <div>
                            <div className="flex justify-between text-sm mb-1">
                              <span>Progress</span>
                              <span className="font-bold">{chapter.progress}%</span>
                            </div>
                            <Progress value={chapter.progress} className="h-2" />
                          </div>
                          
                          <div className="grid grid-cols-3 gap-4 text-sm">
                            <div className="flex items-center">
                              <Clock className="w-4 h-4 mr-1 text-blue-500" />
                              <span>{chapter.timeRequired}</span>
                            </div>
                            <div className="flex items-center">
                              <Target className="w-4 h-4 mr-1 text-green-500" />
                              <span>{chapter.questionsCount} questions</span>
                            </div>
                            <div className="flex items-center">
                              <Video className="w-4 h-4 mr-1 text-purple-500" />
                              <span>{chapter.videoLectures} lectures</span>
                            </div>
                          </div>
                          
                          <div className="flex flex-wrap gap-1">
                            {chapter.topics.slice(0, 3).map((topic, index) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                {topic}
                              </Badge>
                            ))}
                            {chapter.topics.length > 3 && (
                              <Badge variant="outline" className="text-xs">
                                +{chapter.topics.length - 3} more
                              </Badge>
                            )}
                          </div>
                          
                          <Button 
                            className="w-full bg-gradient-to-r from-blue-500 to-blue-700 text-white border-0"
                          >
                            {chapter.completed ? "Review Chapter" : "Continue Study"}
                            <ArrowRight className="w-4 h-4 ml-2" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Study Tools */}
            <Card className="shadow-2xl border-0">
              <CardHeader>
                <CardTitle className="text-2xl font-bold flex items-center">
                  <Zap className="w-6 h-6 mr-3 text-yellow-600" />
                  Physics Study Tools
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="practice" className="w-full">
                  <TabsList className="grid w-full grid-cols-4">
                    <TabsTrigger value="practice">Practice</TabsTrigger>
                    <TabsTrigger value="formulas">Formulas</TabsTrigger>
                    <TabsTrigger value="videos">Videos</TabsTrigger>
                    <TabsTrigger value="notes">Notes</TabsTrigger>
                  </TabsList>

                  <TabsContent value="practice" className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Card className="border-2 hover:border-blue-500 transition-all cursor-pointer">
                        <CardContent className="p-4 text-center">
                          <Timer className="w-12 h-12 text-blue-600 mx-auto mb-3" />
                          <h3 className="font-bold mb-2">Quick Practice</h3>
                          <p className="text-sm text-muted-foreground mb-3">20 random questions</p>
                          <Button className="w-full">Start Practice</Button>
                        </CardContent>
                      </Card>
                      
                      <Card className="border-2 hover:border-green-500 transition-all cursor-pointer">
                        <CardContent className="p-4 text-center">
                          <Target className="w-12 h-12 text-green-600 mx-auto mb-3" />
                          <h3 className="font-bold mb-2">Topic Wise</h3>
                          <p className="text-sm text-muted-foreground mb-3">Chapter specific practice</p>
                          <Button variant="outline" className="w-full">Select Topic</Button>
                        </CardContent>
                      </Card>
                    </div>
                  </TabsContent>

                  <TabsContent value="formulas" className="space-y-4">
                    <div className="space-y-3">
                      {physicsFormulas.map((formula, index) => (
                        <Card key={index} className="border-l-4 border-l-blue-500">
                          <CardContent className="p-4">
                            <div className="flex items-center justify-between">
                              <div>
                                <Badge variant="outline" className="mb-2">{formula.topic}</Badge>
                                <div className="font-mono text-lg font-bold mb-1">{formula.formula}</div>
                                <p className="text-sm text-muted-foreground">{formula.description}</p>
                              </div>
                              <Button size="sm" variant="outline">
                                <BookMarked className="w-4 h-4" />
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </TabsContent>

                  <TabsContent value="videos" className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {physicsChapters.slice(0, 4).map((chapter) => (
                        <Card key={chapter.id} className="border-2 hover:shadow-lg transition-all cursor-pointer">
                          <CardContent className="p-4">
                            <div className="flex items-center space-x-3 mb-3">
                              <div className="w-12 h-12 bg-gradient-to-br from-red-500 to-red-700 rounded-lg flex items-center justify-center">
                                <Play className="w-6 h-6 text-white" />
                              </div>
                              <div>
                                <h3 className="font-bold">{chapter.title}</h3>
                                <p className="text-sm text-muted-foreground">{chapter.videoLectures} lectures</p>
                              </div>
                            </div>
                            <Button variant="outline" className="w-full">
                              Watch Lectures
                            </Button>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </TabsContent>

                  <TabsContent value="notes" className="space-y-4">
                    <div className="text-center py-8">
                      <FileText className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                      <h3 className="text-xl font-bold mb-2">Study Notes</h3>
                      <p className="text-muted-foreground mb-4">Create and organize your physics notes</p>
                      <Button>
                        <Plus className="w-4 h-4 mr-2" />
                        Create New Note
                      </Button>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Current Chapter Detail */}
            {selectedChapter && (
              <Card className="shadow-2xl border-0">
                <CardHeader>
                  <CardTitle className="text-lg">Chapter Focus</CardTitle>
                </CardHeader>
                <CardContent>
                  {(() => {
                    const chapter = physicsChapters.find(ch => ch.id === selectedChapter);
                    if (!chapter) return null;
                    
                    return (
                      <div className="space-y-4">
                        <div>
                          <h3 className="font-bold text-lg mb-2">{chapter.title}</h3>
                          <Progress value={chapter.progress} className="mb-2" />
                          <p className="text-sm text-muted-foreground">{chapter.progress}% completed</p>
                        </div>
                        
                        <div className="space-y-2">
                          <h4 className="font-semibold">Key Topics:</h4>
                          {chapter.topics.map((topic, index) => (
                            <div key={index} className="flex items-center text-sm">
                              <CheckCircle className="w-3 h-3 mr-2 text-green-500" />
                              {topic}
                            </div>
                          ))}
                        </div>
                        
                        <Button className="w-full bg-gradient-to-r from-blue-500 to-blue-700 text-white border-0">
                          Continue Chapter
                        </Button>
                      </div>
                    );
                  })()}
                </CardContent>
              </Card>
            )}

            {/* Recent Activity */}
            <Card className="shadow-2xl border-0">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <BarChart3 className="w-5 h-5 mr-2 text-green-500" />
                  Recent Activity
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {recentSolvedQuestions.map((question) => (
                    <div key={question.id} className="flex items-start space-x-3 p-3 bg-gray-50 rounded-lg">
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                        question.solved ? 'bg-green-100' : 'bg-red-100'
                      }`}>
                        {question.solved ? (
                          <CheckCircle className="w-4 h-4 text-green-600" />
                        ) : (
                          <Clock className="w-4 h-4 text-red-600" />
                        )}
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium truncate">{question.question}</p>
                        <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                          <span>{question.topic}</span>
                          <span>•</span>
                          <span>{question.timeSpent}</span>
                          {question.solved && (
                            <>
                              <span>•</span>
                              <span className="text-green-600">{question.accuracy}%</span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Performance Stats */}
            <Card className="shadow-2xl border-0">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <TrendingUp className="w-5 h-5 mr-2 text-blue-500" />
                  This Week
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Questions Solved</span>
                    <span className="font-bold text-blue-600">68</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Study Hours</span>
                    <span className="font-bold text-green-600">12.5h</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Average Accuracy</span>
                    <span className="font-bold text-purple-600">89%</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Chapters Completed</span>
                    <span className="font-bold text-orange-600">1</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="shadow-2xl border-0">
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button variant="outline" className="w-full justify-start">
                  <Brain className="w-4 h-4 mr-2" />
                  Ask Physics Doubt
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Users className="w-4 h-4 mr-2" />
                  Join Study Group
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Calculator className="w-4 h-4 mr-2" />
                  Physics Calculator
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
