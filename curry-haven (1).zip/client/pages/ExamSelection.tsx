import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  BookOpen, 
  Clock, 
  Users, 
  Target, 
  ArrowRight, 
  CheckCircle, 
  Star,
  Calendar,
  TrendingUp,
  Award,
  Zap
} from "lucide-react";

const examDetails = {
  jee: {
    name: "JEE Main & Advanced",
    fullName: "Joint Entrance Examination",
    description: "India's premier engineering entrance exam for IITs, NITs, and other top colleges",
    difficulty: "High",
    duration: "3 hours",
    subjects: ["Physics", "Chemistry", "Mathematics"],
    totalStudents: "2,100,000+",
    successRate: "2.5%",
    avgPreparationTime: "2 years",
    topColleges: ["IIT Delhi", "IIT Bombay", "IIT Madras", "NIT Trichy"],
    examPattern: {
      totalQuestions: 90,
      maxMarks: 300,
      negativeMarking: "-1 for wrong answer"
    },
    nextExamDate: "April 2024",
    registrationFee: "₹650",
    color: "from-blue-500 to-blue-700"
  },
  cat: {
    name: "CAT",
    fullName: "Common Admission Test",
    description: "Gateway to India's top MBA programs including IIMs",
    difficulty: "High",
    duration: "2 hours",
    subjects: ["Verbal Ability", "Data Interpretation", "Quantitative Aptitude"],
    totalStudents: "800,000+",
    successRate: "1.2%",
    avgPreparationTime: "1-2 years",
    topColleges: ["IIM Ahmedabad", "IIM Bangalore", "IIM Calcutta", "IIM Lucknow"],
    examPattern: {
      totalQuestions: 76,
      maxMarks: 300,
      negativeMarking: "-1 for wrong answer"
    },
    nextExamDate: "November 2024",
    registrationFee: "₹2,300",
    color: "from-purple-500 to-purple-700"
  },
  gate: {
    name: "GATE",
    fullName: "Graduate Aptitude Test in Engineering",
    description: "For postgraduate programs and PSU jobs in engineering and science",
    difficulty: "Medium-High",
    duration: "3 hours",
    subjects: ["Engineering Mathematics", "General Aptitude", "Core Subject"],
    totalStudents: "1,100,000+",
    successRate: "15%",
    avgPreparationTime: "8-12 months",
    topColleges: ["IISc Bangalore", "IIT Delhi", "IIT Bombay", "IIT Kharagpur"],
    examPattern: {
      totalQuestions: 65,
      maxMarks: 100,
      negativeMarking: "-1/3 for 1 mark, -2/3 for 2 marks"
    },
    nextExamDate: "February 2024",
    registrationFee: "₹1,800",
    color: "from-indigo-500 to-indigo-700"
  },
  nda: {
    name: "NDA & NA",
    fullName: "National Defence Academy & Naval Academy",
    description: "Join Indian Armed Forces as an officer through this prestigious exam",
    difficulty: "Medium",
    duration: "2.5 hours (Written) + SSB",
    subjects: ["Mathematics", "General Ability Test"],
    totalStudents: "500,000+",
    successRate: "0.8%",
    avgPreparationTime: "1-2 years",
    topColleges: ["NDA Khadakwasla", "Naval Academy Ezhimala"],
    examPattern: {
      totalQuestions: 270,
      maxMarks: 900,
      negativeMarking: "-1/3 for wrong answer"
    },
    nextExamDate: "April 2024",
    registrationFee: "Free",
    color: "from-green-500 to-green-700"
  },
  afcat: {
    name: "AFCAT",
    fullName: "Air Force Common Admission Test",
    description: "Entry into Indian Air Force as a commissioned officer",
    difficulty: "Medium",
    duration: "2 hours",
    subjects: ["General Awareness", "Verbal Ability", "Numerical Ability", "Reasoning"],
    totalStudents: "300,000+",
    successRate: "2%",
    avgPreparationTime: "6-12 months",
    topColleges: ["Air Force Academy Hyderabad"],
    examPattern: {
      totalQuestions: 100,
      maxMarks: 300,
      negativeMarking: "-1 for wrong answer"
    },
    nextExamDate: "February 2024",
    registrationFee: "₹550",
    color: "from-orange-500 to-orange-700"
  },
  cds: {
    name: "CDS",
    fullName: "Combined Defence Services",
    description: "Entry into Indian Military Academy, Naval Academy, and Air Force Academy",
    difficulty: "Medium",
    duration: "2 hours each paper",
    subjects: ["English", "General Knowledge", "Elementary Mathematics"],
    totalStudents: "400,000+",
    successRate: "1.5%",
    avgPreparationTime: "8-12 months",
    topColleges: ["IMA Dehradun", "Naval Academy Ezhimala", "AFA Hyderabad"],
    examPattern: {
      totalQuestions: 340,
      maxMarks: 300,
      negativeMarking: "-1/3 for wrong answer"
    },
    nextExamDate: "April 2024",
    registrationFee: "₹200",
    color: "from-teal-500 to-teal-700"
  },
  gmat: {
    name: "GMAT",
    fullName: "Graduate Management Admission Test",
    description: "For admission to international MBA programs worldwide",
    difficulty: "High",
    duration: "3 hours 7 minutes",
    subjects: ["Analytical Writing", "Integrated Reasoning", "Quantitative", "Verbal"],
    totalStudents: "200,000+",
    successRate: "Variable",
    avgPreparationTime: "3-6 months",
    topColleges: ["Harvard Business School", "Stanford GSB", "Wharton", "INSEAD"],
    examPattern: {
      totalQuestions: 80,
      maxMarks: 800,
      negativeMarking: "Computer Adaptive"
    },
    nextExamDate: "Year Round",
    registrationFee: "$275",
    color: "from-red-500 to-red-700"
  }
};

const examCards = [
  { id: "jee", icon: "🔬", popular: true },
  { id: "cat", icon: "💼", popular: true },
  { id: "gate", icon: "⚙️", popular: false },
  { id: "nda", icon: "🛡️", popular: false },
  { id: "afcat", icon: "✈️", popular: false },
  { id: "cds", icon: "🎖️", popular: false },
  { id: "gmat", icon: "🌍", popular: false }
];

export default function ExamSelection() {
  const [selectedExam, setSelectedExam] = useState<keyof typeof examDetails | null>(null);
  const navigate = useNavigate();

  const handleExamSelect = (examId: keyof typeof examDetails) => {
    setSelectedExam(examId);
  };

  const handleStartPreparation = () => {
    if (selectedExam) {
      navigate(`/dashboard/${selectedExam}`);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 gradient-purple rounded-lg flex items-center justify-center">
                <BookOpen className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gradient">StudyBuddy AI</h1>
                <p className="text-xs text-muted-foreground">Choose Your Exam</p>
              </div>
            </div>
            <Button variant="outline" onClick={() => navigate("/")}>
              Back to Home
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-6 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4 text-gradient">
            Choose Your Competitive Exam
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Select from India's top competitive exams and start your AI-powered preparation journey. 
            Each exam has specialized modules designed for maximum success.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Exam Cards */}
          <div className="lg:col-span-2">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {examCards.map((exam) => {
                const details = examDetails[exam.id];
                const isSelected = selectedExam === exam.id;
                
                return (
                  <Card 
                    key={exam.id}
                    className={`cursor-pointer transition-all duration-300 hover:shadow-lg ${
                      isSelected ? 'ring-2 ring-primary shadow-lg scale-105' : ''
                    } ${exam.popular ? 'border-primary/50' : ''}`}
                    onClick={() => handleExamSelect(exam.id)}
                  >
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div className="text-3xl">{exam.icon}</div>
                        <div className="flex flex-col items-end space-y-1">
                          {exam.popular && (
                            <Badge className="bg-gradient-to-r from-orange-400 to-red-500 text-white border-0">
                              🔥 Popular
                            </Badge>
                          )}
                          <Badge variant="secondary" className="text-xs">
                            {details.totalStudents} students
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <CardTitle className="text-xl mb-2">{details.name}</CardTitle>
                      <CardDescription className="mb-4">
                        {details.description}
                      </CardDescription>
                      
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-sm">
                          <span className="flex items-center">
                            <Target className="w-4 h-4 mr-1 text-blue-500" />
                            Success Rate
                          </span>
                          <span className="font-semibold">{details.successRate}</span>
                        </div>
                        <div className="flex items-center justify-between text-sm">
                          <span className="flex items-center">
                            <Clock className="w-4 h-4 mr-1 text-green-500" />
                            Prep Time
                          </span>
                          <span className="font-semibold">{details.avgPreparationTime}</span>
                        </div>
                        <div className="flex items-center justify-between text-sm">
                          <span className="flex items-center">
                            <Calendar className="w-4 h-4 mr-1 text-purple-500" />
                            Next Exam
                          </span>
                          <span className="font-semibold">{details.nextExamDate}</span>
                        </div>
                      </div>

                      {isSelected && (
                        <div className="mt-4 p-3 bg-primary/5 rounded-lg">
                          <div className="flex items-center text-primary text-sm font-medium">
                            <CheckCircle className="w-4 h-4 mr-1" />
                            Selected for AI-powered preparation
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>

          {/* Detailed View */}
          <div className="lg:col-span-1">
            {selectedExam ? (
              <Card className="sticky top-24">
                <CardHeader>
                  <div className={`w-full h-24 bg-gradient-to-r ${examDetails[selectedExam].color} rounded-lg flex items-center justify-center mb-4`}>
                    <h3 className="text-2xl font-bold text-white">
                      {examDetails[selectedExam].name}
                    </h3>
                  </div>
                  <CardTitle className="text-xl">
                    {examDetails[selectedExam].fullName}
                  </CardTitle>
                  <CardDescription>
                    {examDetails[selectedExam].description}
                  </CardDescription>
                </CardHeader>
                
                <CardContent className="space-y-6">
                  {/* Exam Pattern */}
                  <div>
                    <h4 className="font-semibold mb-3 flex items-center">
                      <Award className="w-5 h-5 mr-2 text-primary" />
                      Exam Pattern
                    </h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span>Total Questions:</span>
                        <span className="font-semibold">{examDetails[selectedExam].examPattern.totalQuestions}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Maximum Marks:</span>
                        <span className="font-semibold">{examDetails[selectedExam].examPattern.maxMarks}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Duration:</span>
                        <span className="font-semibold">{examDetails[selectedExam].duration}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Negative Marking:</span>
                        <span className="font-semibold text-red-500">{examDetails[selectedExam].examPattern.negativeMarking}</span>
                      </div>
                    </div>
                  </div>

                  {/* Subjects */}
                  <div>
                    <h4 className="font-semibold mb-3 flex items-center">
                      <BookOpen className="w-5 h-5 mr-2 text-primary" />
                      Subjects
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {examDetails[selectedExam].subjects.map((subject, index) => (
                        <Badge key={index} variant="secondary">
                          {subject}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  {/* Top Colleges */}
                  <div>
                    <h4 className="font-semibold mb-3 flex items-center">
                      <Star className="w-5 h-5 mr-2 text-primary" />
                      Top Colleges
                    </h4>
                    <div className="space-y-1 text-sm">
                      {examDetails[selectedExam].topColleges.slice(0, 3).map((college, index) => (
                        <div key={index} className="flex items-center">
                          <CheckCircle className="w-3 h-3 mr-2 text-green-500" />
                          {college}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Stats */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-3 bg-blue-50 rounded-lg">
                      <Users className="w-6 h-6 text-blue-500 mx-auto mb-1" />
                      <div className="text-sm font-semibold text-blue-700">
                        {examDetails[selectedExam].totalStudents}
                      </div>
                      <div className="text-xs text-blue-600">Total Students</div>
                    </div>
                    <div className="text-center p-3 bg-green-50 rounded-lg">
                      <TrendingUp className="w-6 h-6 text-green-500 mx-auto mb-1" />
                      <div className="text-sm font-semibold text-green-700">
                        {examDetails[selectedExam].successRate}
                      </div>
                      <div className="text-xs text-green-600">Success Rate</div>
                    </div>
                  </div>

                  {/* Registration Fee */}
                  <div className="p-4 bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold">Registration Fee</span>
                      <span className="text-lg font-bold text-primary">
                        {examDetails[selectedExam].registrationFee}
                      </span>
                    </div>
                  </div>

                  {/* Action Button */}
                  <Button 
                    className="w-full text-lg py-6" 
                    onClick={handleStartPreparation}
                  >
                    <Zap className="w-5 h-5 mr-2" />
                    Start AI-Powered Preparation
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Button>

                  <div className="text-center">
                    <p className="text-xs text-muted-foreground">
                      ✨ Includes AI tutoring, group study, progress tracking & more
                    </p>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card className="sticky top-24">
                <CardContent className="flex items-center justify-center h-64">
                  <div className="text-center">
                    <Target className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground">
                      Select an exam to see detailed information and start your preparation
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* Features Preview */}
        <div className="mt-16">
          <h2 className="text-2xl font-bold text-center mb-8">What You Get with StudyBuddy AI</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="text-center p-6">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <BookOpen className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="font-semibold mb-2">AI Study Plans</h3>
              <p className="text-sm text-muted-foreground">Personalized study schedules based on your exam and timeline</p>
            </Card>
            
            <Card className="text-center p-6">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Users className="w-6 h-6 text-green-600" />
              </div>
              <h3 className="font-semibold mb-2">Group Study</h3>
              <p className="text-sm text-muted-foreground">Join live study sessions with peers preparing for the same exam</p>
            </Card>
            
            <Card className="text-center p-6">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <TrendingUp className="w-6 h-6 text-purple-600" />
              </div>
              <h3 className="font-semibold mb-2">Progress Analytics</h3>
              <p className="text-sm text-muted-foreground">Real-time insights into your preparation and performance</p>
            </Card>
            
            <Card className="text-center p-6">
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Zap className="w-6 h-6 text-orange-600" />
              </div>
              <h3 className="font-semibold mb-2">AI Doubt Solving</h3>
              <p className="text-sm text-muted-foreground">Instant answers to your questions in Hindi and English</p>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
