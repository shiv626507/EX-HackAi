import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Timer, 
  BookOpen, 
  Target, 
  Play, 
  Pause,
  ArrowRight,
  ArrowLeft,
  Flag,
  CheckCircle,
  XCircle,
  Clock,
  Calculator,
  FileText,
  BarChart3,
  Award,
  TrendingUp,
  Users,
  Star,
  RefreshCw,
  Download,
  Share2,
  Eye,
  Brain,
  Zap,
  GraduationCap,
  AlertCircle
} from "lucide-react";

interface Question {
  id: number;
  subject: 'Physics' | 'Chemistry' | 'Mathematics';
  question: string;
  options: string[];
  correctAnswer: number;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  marks: number;
  negativeMarks: number;
  timeRecommended: number; // in seconds
  topic: string;
  year?: number;
  explanation?: string;
  userAnswer?: number;
  timeTaken?: number;
  flagged?: boolean;
}

const mockQuestions: Question[] = [
  {
    id: 1,
    subject: 'Physics',
    question: 'A particle moves in a straight line with constant acceleration. If its velocity changes from 10 m/s to 30 m/s in 4 seconds, what is the acceleration?',
    options: ['2.5 m/s²', '5 m/s²', '7.5 m/s²', '10 m/s²'],
    correctAnswer: 1,
    difficulty: 'Easy',
    marks: 4,
    negativeMarks: -1,
    timeRecommended: 120,
    topic: 'Kinematics',
    year: 2023,
    explanation: 'Using the equation v = u + at, where v = 30 m/s, u = 10 m/s, t = 4s. Therefore, a = (v-u)/t = (30-10)/4 = 5 m/s²'
  },
  {
    id: 2,
    subject: 'Chemistry',
    question: 'Which of the following compounds exhibits both ionic and covalent bonding?',
    options: ['NaCl', 'NH₄Cl', 'CO₂', 'H₂O'],
    correctAnswer: 1,
    difficulty: 'Medium',
    marks: 4,
    negativeMarks: -1,
    timeRecommended: 90,
    topic: 'Chemical Bonding',
    year: 2023,
    explanation: 'NH₄Cl contains NH₄⁺ ion (covalent bonding within the ion) and Cl⁻ ion, held together by ionic bonding.'
  },
  {
    id: 3,
    subject: 'Mathematics',
    question: 'Find the derivative of f(x) = x³ - 2x² + 5x - 3',
    options: ['3x² - 4x + 5', '3x² - 2x + 5', '3x³ - 4x² + 5x', 'x² - 4x + 5'],
    correctAnswer: 0,
    difficulty: 'Easy',
    marks: 4,
    negativeMarks: -1,
    timeRecommended: 100,
    topic: 'Differentiation',
    year: 2022,
    explanation: 'Using the power rule: d/dx(x³) = 3x², d/dx(-2x²) = -4x, d/dx(5x) = 5, d/dx(-3) = 0'
  }
  // Add more questions as needed
];

const testConfigs = [
  {
    id: 'jee-main-full',
    name: 'JEE Main Full Test',
    duration: 180, // 3 hours
    questions: 90,
    subjects: { Physics: 30, Chemistry: 30, Mathematics: 30 },
    totalMarks: 360,
    description: 'Complete JEE Main simulation with all three subjects'
  },
  {
    id: 'jee-advanced-paper1',
    name: 'JEE Advanced Paper 1',
    duration: 180,
    questions: 54,
    subjects: { Physics: 18, Chemistry: 18, Mathematics: 18 },
    totalMarks: 248,
    description: 'JEE Advanced Paper 1 pattern with multiple correct answers'
  },
  {
    id: 'physics-only',
    name: 'Physics Subject Test',
    duration: 60,
    questions: 30,
    subjects: { Physics: 30 },
    totalMarks: 120,
    description: 'Focused Physics practice test'
  }
];

export default function JEEMockTest() {
  const navigate = useNavigate();
  const [testStarted, setTestStarted] = useState(false);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [timeRemaining, setTimeRemaining] = useState(180 * 60); // 3 hours in seconds
  const [questions, setQuestions] = useState<Question[]>(mockQuestions);
  const [testCompleted, setTestCompleted] = useState(false);
  const [selectedConfig, setSelectedConfig] = useState(testConfigs[0]);
  const [isReviewMode, setIsReviewMode] = useState(false);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (testStarted && !testCompleted && timeRemaining > 0) {
      interval = setInterval(() => {
        setTimeRemaining(prev => {
          if (prev <= 1) {
            setTestCompleted(true);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [testStarted, testCompleted, timeRemaining]);

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleAnswerSelect = (answerIndex: number) => {
    const updatedQuestions = [...questions];
    updatedQuestions[currentQuestion].userAnswer = answerIndex;
    setQuestions(updatedQuestions);
  };

  const handleFlagQuestion = () => {
    const updatedQuestions = [...questions];
    updatedQuestions[currentQuestion].flagged = !updatedQuestions[currentQuestion].flagged;
    setQuestions(updatedQuestions);
  };

  const navigateQuestion = (direction: 'prev' | 'next') => {
    if (direction === 'prev' && currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    } else if (direction === 'next' && currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    }
  };

  const submitTest = () => {
    setTestCompleted(true);
    setIsReviewMode(true);
  };

  const calculateResults = () => {
    let correct = 0;
    let incorrect = 0;
    let unattempted = 0;
    let totalMarks = 0;

    questions.forEach(q => {
      if (q.userAnswer === undefined) {
        unattempted++;
      } else if (q.userAnswer === q.correctAnswer) {
        correct++;
        totalMarks += q.marks;
      } else {
        incorrect++;
        totalMarks += q.negativeMarks;
      }
    });

    return { correct, incorrect, unattempted, totalMarks };
  };

  const getQuestionStatus = (index: number) => {
    const q = questions[index];
    if (q.userAnswer !== undefined) {
      return isReviewMode ? (q.userAnswer === q.correctAnswer ? 'correct' : 'incorrect') : 'answered';
    }
    return q.flagged ? 'flagged' : 'unattempted';
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'correct': return 'bg-green-500 text-white';
      case 'incorrect': return 'bg-red-500 text-white';
      case 'answered': return 'bg-blue-500 text-white';
      case 'flagged': return 'bg-orange-500 text-white';
      case 'current': return 'bg-purple-500 text-white';
      default: return 'bg-gray-200 text-gray-700';
    }
  };

  if (!testStarted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
        {/* Header */}
        <header className="border-b bg-white/90 backdrop-blur-sm">
          <div className="container mx-auto px-6 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <Button variant="outline" onClick={() => navigate("/dashboard")}>
                  ← Back to Dashboard
                </Button>
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-xl flex items-center justify-center shadow-lg">
                    <Timer className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h1 className="text-2xl font-bold text-gradient-jee">JEE Mock Tests</h1>
                    <p className="text-sm text-muted-foreground">Practice with real exam simulation</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </header>

        <div className="container mx-auto px-6 py-12">
          {/* Test Selection */}
          <Card className="max-w-4xl mx-auto shadow-2xl border-0">
            <CardHeader className="text-center">
              <CardTitle className="text-3xl font-bold text-gradient-jee mb-4">Choose Your Mock Test</CardTitle>
              <CardDescription className="text-lg">
                Select from various JEE test patterns and difficulty levels
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                {testConfigs.map((config) => (
                  <Card 
                    key={config.id}
                    className={`cursor-pointer transition-all duration-300 border-2 hover:shadow-lg ${
                      selectedConfig.id === config.id ? 'ring-2 ring-primary shadow-lg' : ''
                    }`}
                    onClick={() => setSelectedConfig(config)}
                  >
                    <CardContent className="p-6">
                      <h3 className="font-bold text-lg mb-3">{config.name}</h3>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span>Duration:</span>
                          <span className="font-bold">{config.duration} min</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Questions:</span>
                          <span className="font-bold">{config.questions}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Total Marks:</span>
                          <span className="font-bold">{config.totalMarks}</span>
                        </div>
                      </div>
                      <p className="text-xs text-muted-foreground mt-3">{config.description}</p>
                      
                      <div className="mt-4 flex flex-wrap gap-1">
                        {Object.entries(config.subjects).map(([subject, count]) => (
                          <Badge key={subject} variant="outline" className="text-xs">
                            {subject}: {count}
                          </Badge>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Test Instructions */}
              <Card className="mb-6 border-l-4 border-l-yellow-500">
                <CardHeader>
                  <CardTitle className="flex items-center text-lg">
                    <AlertCircle className="w-5 h-5 mr-2 text-yellow-600" />
                    Important Instructions
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-start">
                      <CheckCircle className="w-4 h-4 mr-2 text-green-500 mt-0.5 flex-shrink-0" />
                      Each correct answer carries +4 marks
                    </li>
                    <li className="flex items-start">
                      <XCircle className="w-4 h-4 mr-2 text-red-500 mt-0.5 flex-shrink-0" />
                      Each incorrect answer has -1 mark (negative marking)
                    </li>
                    <li className="flex items-start">
                      <Clock className="w-4 h-4 mr-2 text-blue-500 mt-0.5 flex-shrink-0" />
                      Timer will start once you begin the test
                    </li>
                    <li className="flex items-start">
                      <Flag className="w-4 h-4 mr-2 text-orange-500 mt-0.5 flex-shrink-0" />
                      You can flag questions for review
                    </li>
                    <li className="flex items-start">
                      <Calculator className="w-4 h-4 mr-2 text-purple-500 mt-0.5 flex-shrink-0" />
                      Basic calculator and rough sheet available
                    </li>
                  </ul>
                </CardContent>
              </Card>

              {/* Start Test Button */}
              <div className="text-center">
                <Button 
                  size="lg" 
                  className="text-xl px-12 py-6 gradient-jee-primary text-white border-0 shadow-xl hover:shadow-2xl"
                  onClick={() => {
                    setTestStarted(true);
                    setTimeRemaining(selectedConfig.duration * 60);
                  }}
                >
                  <Play className="w-6 h-6 mr-3" />
                  Start {selectedConfig.name}
                  <ArrowRight className="w-6 h-6 ml-3" />
                </Button>
                <p className="text-sm text-muted-foreground mt-4">
                  Make sure you have a stable internet connection
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (testCompleted && isReviewMode) {
    const results = calculateResults();
    const percentage = Math.round((results.totalMarks / selectedConfig.totalMarks) * 100);
    
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 via-blue-50 to-purple-50">
        <div className="container mx-auto px-6 py-12">
          <Card className="max-w-4xl mx-auto shadow-2xl border-0">
            <CardHeader className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-green-500 to-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Trophy className="w-10 h-10 text-white" />
              </div>
              <CardTitle className="text-3xl font-bold text-gradient-jee">Test Completed!</CardTitle>
              <CardDescription className="text-lg">Here's your performance analysis</CardDescription>
            </CardHeader>
            
            <CardContent>
              {/* Overall Score */}
              <div className="text-center mb-8">
                <div className="text-6xl font-bold text-gradient-jee mb-2">{results.totalMarks}</div>
                <div className="text-xl text-muted-foreground">out of {selectedConfig.totalMarks} marks</div>
                <div className="text-2xl font-bold text-green-600 mt-2">{percentage}%</div>
              </div>

              {/* Detailed Results */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                <Card className="border-2 border-green-200 bg-green-50">
                  <CardContent className="p-4 text-center">
                    <CheckCircle className="w-8 h-8 text-green-600 mx-auto mb-2" />
                    <div className="text-2xl font-bold text-green-600">{results.correct}</div>
                    <div className="text-sm text-green-700">Correct</div>
                  </CardContent>
                </Card>
                
                <Card className="border-2 border-red-200 bg-red-50">
                  <CardContent className="p-4 text-center">
                    <XCircle className="w-8 h-8 text-red-600 mx-auto mb-2" />
                    <div className="text-2xl font-bold text-red-600">{results.incorrect}</div>
                    <div className="text-sm text-red-700">Incorrect</div>
                  </CardContent>
                </Card>
                
                <Card className="border-2 border-gray-200 bg-gray-50">
                  <CardContent className="p-4 text-center">
                    <Clock className="w-8 h-8 text-gray-600 mx-auto mb-2" />
                    <div className="text-2xl font-bold text-gray-600">{results.unattempted}</div>
                    <div className="text-sm text-gray-700">Unattempted</div>
                  </CardContent>
                </Card>
                
                <Card className="border-2 border-blue-200 bg-blue-50">
                  <CardContent className="p-4 text-center">
                    <BarChart3 className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                    <div className="text-2xl font-bold text-blue-600">{Math.round((results.correct / questions.length) * 100)}%</div>
                    <div className="text-sm text-blue-700">Accuracy</div>
                  </CardContent>
                </Card>
              </div>

              {/* Subject-wise Analysis */}
              <Card className="mb-6">
                <CardHeader>
                  <CardTitle>Subject-wise Performance</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {['Physics', 'Chemistry', 'Mathematics'].map((subject) => {
                      const subjectQuestions = questions.filter(q => q.subject === subject);
                      const subjectCorrect = subjectQuestions.filter(q => q.userAnswer === q.correctAnswer).length;
                      const subjectPercentage = subjectQuestions.length > 0 ? Math.round((subjectCorrect / subjectQuestions.length) * 100) : 0;
                      
                      return (
                        <div key={subject}>
                          <div className="flex justify-between mb-2">
                            <span className="font-semibold">{subject}</span>
                            <span className="font-bold">{subjectCorrect}/{subjectQuestions.length} ({subjectPercentage}%)</span>
                          </div>
                          <Progress value={subjectPercentage} className="h-2" />
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button onClick={() => window.print()} variant="outline" className="border-2">
                  <Download className="w-4 h-4 mr-2" />
                  Download Report
                </Button>
                <Button onClick={() => setIsReviewMode(false)} variant="outline" className="border-2">
                  <Eye className="w-4 h-4 mr-2" />
                  Review Answers
                </Button>
                <Button onClick={() => navigate('/dashboard')} className="gradient-jee-primary text-white border-0">
                  <GraduationCap className="w-4 h-4 mr-2" />
                  Back to Dashboard
                </Button>
                <Button onClick={() => {
                  setTestStarted(false);
                  setTestCompleted(false);
                  setCurrentQuestion(0);
                  setQuestions(mockQuestions.map(q => ({ ...q, userAnswer: undefined, flagged: false })));
                }} className="gradient-jee-secondary text-white border-0">
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Take Another Test
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Test Interface
  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-blue-100">
      {/* Test Header */}
      <header className="bg-white border-b shadow-sm">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <h1 className="text-xl font-bold">{selectedConfig.name}</h1>
              <Badge className="bg-blue-100 text-blue-700 border-0">
                Question {currentQuestion + 1} of {questions.length}
              </Badge>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 bg-red-50 px-4 py-2 rounded-lg">
                <Clock className="w-5 h-5 text-red-600" />
                <span className="font-mono text-lg font-bold text-red-600">
                  {formatTime(timeRemaining)}
                </span>
              </div>
              <Button onClick={submitTest} variant="destructive">
                Submit Test
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-6 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Question Panel */}
          <div className="lg:col-span-3">
            <Card className="shadow-xl border-0 h-full">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Badge className={`${
                      questions[currentQuestion].subject === 'Physics' ? 'bg-blue-100 text-blue-700' :
                      questions[currentQuestion].subject === 'Chemistry' ? 'bg-orange-100 text-orange-700' :
                      'bg-purple-100 text-purple-700'
                    } border-0 font-bold`}>
                      {questions[currentQuestion].subject}
                    </Badge>
                    <Badge className={
                      questions[currentQuestion].difficulty === 'Easy' ? 'bg-green-100 text-green-700' :
                      questions[currentQuestion].difficulty === 'Medium' ? 'bg-yellow-100 text-yellow-700' :
                      'bg-red-100 text-red-700'
                    }>
                      {questions[currentQuestion].difficulty}
                    </Badge>
                    <span className="text-sm text-muted-foreground">
                      +{questions[currentQuestion].marks} | {questions[currentQuestion].negativeMarks}
                    </span>
                  </div>
                  
                  <Button
                    onClick={handleFlagQuestion}
                    variant={questions[currentQuestion].flagged ? "default" : "outline"}
                    size="sm"
                  >
                    <Flag className="w-4 h-4" />
                  </Button>
                </div>
              </CardHeader>
              
              <CardContent className="p-8">
                <div className="space-y-6">
                  <div className="text-lg leading-relaxed">
                    <span className="font-semibold">Q{currentQuestion + 1}. </span>
                    {questions[currentQuestion].question}
                  </div>
                  
                  <div className="space-y-3">
                    {questions[currentQuestion].options.map((option, index) => (
                      <div
                        key={index}
                        className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${
                          questions[currentQuestion].userAnswer === index
                            ? 'border-blue-500 bg-blue-50'
                            : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                        }`}
                        onClick={() => handleAnswerSelect(index)}
                      >
                        <div className="flex items-center space-x-3">
                          <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                            questions[currentQuestion].userAnswer === index
                              ? 'border-blue-500 bg-blue-500'
                              : 'border-gray-300'
                          }`}>
                            {questions[currentQuestion].userAnswer === index && (
                              <CheckCircle className="w-4 h-4 text-white" />
                            )}
                          </div>
                          <span className="font-medium">({String.fromCharCode(65 + index)})</span>
                          <span>{option}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
              
              <div className="p-6 border-t flex justify-between">
                <Button
                  onClick={() => navigateQuestion('prev')}
                  disabled={currentQuestion === 0}
                  variant="outline"
                  className="border-2"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Previous
                </Button>
                
                <div className="flex space-x-2">
                  <Button variant="outline" className="border-2">
                    <Calculator className="w-4 h-4 mr-2" />
                    Calculator
                  </Button>
                  <Button variant="outline" className="border-2">
                    <FileText className="w-4 h-4 mr-2" />
                    Rough Sheet
                  </Button>
                </div>
                
                <Button
                  onClick={() => navigateQuestion('next')}
                  disabled={currentQuestion === questions.length - 1}
                  className="gradient-jee-primary text-white border-0"
                >
                  Next
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </Card>
          </div>

          {/* Question Navigation */}
          <div className="lg:col-span-1">
            <Card className="shadow-xl border-0 sticky top-6">
              <CardHeader>
                <CardTitle className="text-lg">Question Navigator</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Legend */}
                  <div className="text-sm space-y-2">
                    <div className="flex items-center space-x-2">
                      <div className="w-4 h-4 bg-gray-200 rounded"></div>
                      <span>Not Attempted</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-4 h-4 bg-blue-500 rounded"></div>
                      <span>Answered</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-4 h-4 bg-orange-500 rounded"></div>
                      <span>Flagged</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-4 h-4 bg-purple-500 rounded"></div>
                      <span>Current</span>
                    </div>
                  </div>
                  
                  {/* Question Grid */}
                  <div className="grid grid-cols-5 gap-2">
                    {questions.map((_, index) => (
                      <button
                        key={index}
                        onClick={() => setCurrentQuestion(index)}
                        className={`w-10 h-10 rounded text-sm font-bold transition-all ${
                          index === currentQuestion ? 'bg-purple-500 text-white' : getStatusColor(getQuestionStatus(index))
                        } hover:scale-110`}
                      >
                        {index + 1}
                      </button>
                    ))}
                  </div>
                  
                  {/* Progress Summary */}
                  <div className="pt-4 border-t space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Answered:</span>
                      <span className="font-bold">{questions.filter(q => q.userAnswer !== undefined).length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Flagged:</span>
                      <span className="font-bold">{questions.filter(q => q.flagged).length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Remaining:</span>
                      <span className="font-bold">{questions.filter(q => q.userAnswer === undefined).length}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
