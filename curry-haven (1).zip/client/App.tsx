import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import JEEDashboard from "./pages/JEEDashboard";
import JEEPhysics from "./pages/JEEPhysics";
import JEEMockTest from "./pages/JEEMockTest";
import JEEAITutor from "./pages/JEEAITutor";
import Placeholder from "./pages/Placeholder";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/dashboard" element={<JEEDashboard />} />
            <Route path="/study/physics" element={<JEEPhysics />} />
            <Route
              path="/study/chemistry"
              element={
                <Placeholder
                  title="JEE Chemistry"
                  description="Master organic, inorganic, and physical chemistry with AI-powered learning."
                  features={[
                    "Organic reaction mechanisms",
                    "Periodic table trends",
                    "Chemical bonding concepts",
                    "Thermodynamics and kinetics",
                    "Previous year solutions"
                  ]}
                />
              }
            />
            <Route
              path="/study/mathematics"
              element={
                <Placeholder
                  title="JEE Mathematics"
                  description="Comprehensive preparation for calculus, algebra, and coordinate geometry."
                  features={[
                    "Calculus and integration",
                    "Coordinate geometry",
                    "Trigonometry and functions",
                    "Probability and statistics",
                    "Step-by-step solutions"
                  ]}
                />
              }
            />
            <Route path="/mock-test" element={<JEEMockTest />} />
            <Route path="/ai-tutor" element={<JEEAITutor />} />
            <Route
              path="/study-rooms"
              element={
                <Placeholder
                  title="JEE Study Rooms"
                  description="Join live study sessions with fellow JEE aspirants and expert mentors."
                  features={[
                    "Live doubt solving sessions",
                    "Subject-wise study groups",
                    "Interactive whiteboard",
                    "Screen sharing and collaboration",
                    "Expert mentor guidance"
                  ]}
                />
              }
            />
            <Route
              path="/previous-papers"
              element={
                <Placeholder
                  title="JEE Previous Year Papers"
                  description="Practice with authentic JEE Main & Advanced papers from 2015-2024 with AI solutions."
                  features={[
                    "JEE Main 2015-2024 papers",
                    "JEE Advanced 2015-2024 papers",
                    "AI-powered solutions",
                    "Topic-wise question bank",
                    "Performance comparison"
                  ]}
                />
              }
            />
            <Route
              path="/progress"
              element={
                <Placeholder
                  title="JEE Progress Analytics"
                  description="Track your JEE preparation with detailed analytics and AI-powered insights."
                  features={[
                    "Subject-wise progress tracking",
                    "Rank prediction algorithms",
                    "Strength and weakness analysis",
                    "Study time optimization",
                    "Performance comparison with toppers"
                  ]}
                />
              }
            />
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
