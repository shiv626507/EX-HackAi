import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { 
  Users, 
  MessageSquare, 
  Video, 
  Mic, 
  MicOff, 
  VideoOff, 
  Screen, 
  Hand, 
  Send, 
  Settings, 
  Crown,
  UserPlus,
  Volume2,
  VolumeX,
  Phone,
  PhoneOff,
  Share2,
  FileText,
  Clock,
  Target,
  Award,
  Zap,
  BookOpen,
  PenTool,
  Eraser,
  Square,
  Circle,
  Type,
  Undo,
  Redo,
  Save,
  Download,
  Upload,
  Eye,
  EyeOff,
  MessageCircle,
  ThumbsUp,
  Heart,
  Smile,
  MoreHorizontal
} from "lucide-react";

interface Participant {
  id: string;
  name: string;
  avatar: string;
  role: 'moderator' | 'member';
  isVideoOn: boolean;
  isAudioOn: boolean;
  isScreenSharing: boolean;
  handRaised: boolean;
  status: 'online' | 'away' | 'busy';
  joinedAt: Date;
}

interface Message {
  id: string;
  userId: string;
  userName: string;
  content: string;
  timestamp: Date;
  type: 'text' | 'file' | 'system' | 'poll';
  reactions?: { emoji: string; count: number; users: string[] }[];
}

interface StudyRoom {
  id: string;
  name: string;
  subject: string;
  topic: string;
  examType: string;
  participants: Participant[];
  maxParticipants: number;
  isLive: boolean;
  createdBy: string;
  createdAt: Date;
  description: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
}

interface GroupCollaborationProps {
  roomId?: string;
  userId: string;
  userName: string;
  language?: 'en' | 'hi';
  onLeaveRoom?: () => void;
}

export default function GroupCollaboration({
  roomId,
  userId,
  userName,
  language = 'en',
  onLeaveRoom
}: GroupCollaborationProps) {
  const [activeRoom, setActiveRoom] = useState<StudyRoom | null>(null);
  const [participants, setParticipants] = useState<Participant[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [isVideoOn, setIsVideoOn] = useState(false);
  const [isAudioOn, setIsAudioOn] = useState(false);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [handRaised, setHandRaised] = useState(false);
  const [activeTab, setActiveTab] = useState('whiteboard');
  const [isDrawing, setIsDrawing] = useState(false);
  const [drawingTool, setDrawingTool] = useState<'pen' | 'eraser' | 'text' | 'shape'>('pen');
  
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const texts = {
    en: {
      studyRoom: "Study Room",
      participants: "Participants",
      chat: "Chat",
      whiteboard: "Whiteboard",
      resources: "Resources",
      joinRoom: "Join Room",
      leaveRoom: "Leave Room",
      muteAudio: "Mute Audio",
      unmuteAudio: "Unmute Audio",
      turnOffVideo: "Turn Off Video",
      turnOnVideo: "Turn On Video",
      shareScreen: "Share Screen",
      stopSharing: "Stop Sharing",
      raiseHand: "Raise Hand",
      lowerHand: "Lower Hand",
      typeMessage: "Type a message...",
      sendMessage: "Send",
      moderator: "Moderator",
      online: "Online",
      away: "Away",
      busy: "Busy",
      joined: "joined the room",
      left: "left the room",
      handRaisedBy: "raised their hand",
      startedScreenShare: "started screen sharing",
      stoppedScreenShare: "stopped screen sharing",
      drawingTools: "Drawing Tools",
      pen: "Pen",
      eraser: "Eraser",
      shapes: "Shapes",
      text: "Text",
      clear: "Clear",
      save: "Save",
      undo: "Undo",
      redo: "Redo",
      roomInfo: "Room Information",
      studyProgress: "Study Progress",
      timeSpent: "Time Spent",
      questionsAsked: "Questions Asked",
      conceptsCovered: "Concepts Covered"
    },
    hi: {
      studyRoom: "अध्ययन कक्ष",
      participants: "प्रतिभागी",
      chat: "चैट",
      whiteboard: "व्हाइटबोर्ड",
      resources: "संसाधन",
      joinRoom: "कक्ष में शामिल हों",
      leaveRoom: "कक्ष छोड़ें",
      muteAudio: "ऑडियो बंद करें",
      unmuteAudio: "ऑडियो चालू करें",
      turnOffVideo: "वीडियो बंद करें",
      turnOnVideo: "वीडियो चालू करें",
      shareScreen: "स्क्रीन साझा करें",
      stopSharing: "साझाकरण बंद करें",
      raiseHand: "हाथ उठाएं",
      lowerHand: "हाथ नीचे करें",
      typeMessage: "संदेश टाइप करें...",
      sendMessage: "भेजें",
      moderator: "संचालक",
      online: "ऑनलाइन",
      away: "दूर",
      busy: "व्यस्त",
      joined: "कक्ष में शामिल हुआ",
      left: "कक्ष छोड़ दिया",
      handRaisedBy: "ने हाथ उठाया",
      startedScreenShare: "स्क्रीन साझाकरण शुरू किया",
      stoppedScreenShare: "स्क्रीन साझाकरण बंद किया",
      drawingTools: "ड्रॉइंग टूल्स",
      pen: "पेन",
      eraser: "रबर",
      shapes: "आकार",
      text: "टेक्स्ट",
      clear: "साफ करें",
      save: "से��� करें",
      undo: "वापस करें",
      redo: "दोबारा करें",
      roomInfo: "कक्ष की जानकारी",
      studyProgress: "अध्ययन प्रगति",
      timeSpent: "बिताया गया समय",
      questionsAsked: "पूछे गए प्रश्न",
      conceptsCovered: "कवर की गई अवधारणाएं"
    }
  };

  const t = texts[language];

  // Sample data
  useEffect(() => {
    // Initialize with sample data
    const sampleRoom: StudyRoom = {
      id: roomId || 'room-1',
      name: 'JEE Physics - Thermodynamics',
      subject: 'Physics',
      topic: 'Thermodynamics',
      examType: 'JEE',
      participants: [],
      maxParticipants: 50,
      isLive: true,
      createdBy: 'user-1',
      createdAt: new Date(),
      description: 'Deep dive into thermodynamics concepts with problem solving',
      difficulty: 'Advanced'
    };

    const sampleParticipants: Participant[] = [
      {
        id: 'user-1',
        name: 'Rahul Sharma',
        avatar: '/placeholder.svg',
        role: 'moderator',
        isVideoOn: true,
        isAudioOn: true,
        isScreenSharing: false,
        handRaised: false,
        status: 'online',
        joinedAt: new Date(Date.now() - 3600000)
      },
      {
        id: userId,
        name: userName,
        avatar: '/placeholder.svg',
        role: 'member',
        isVideoOn: isVideoOn,
        isAudioOn: isAudioOn,
        isScreenSharing: isScreenSharing,
        handRaised: handRaised,
        status: 'online',
        joinedAt: new Date()
      },
      {
        id: 'user-3',
        name: 'Priya Patel',
        avatar: '/placeholder.svg',
        role: 'member',
        isVideoOn: true,
        isAudioOn: false,
        isScreenSharing: false,
        handRaised: true,
        status: 'online',
        joinedAt: new Date(Date.now() - 1800000)
      },
      {
        id: 'user-4',
        name: 'Arjun Singh',
        avatar: '/placeholder.svg',
        role: 'member',
        isVideoOn: false,
        isAudioOn: true,
        isScreenSharing: false,
        handRaised: false,
        status: 'away',
        joinedAt: new Date(Date.now() - 900000)
      }
    ];

    const sampleMessages: Message[] = [
      {
        id: 'msg-1',
        userId: 'user-1',
        userName: 'Rahul Sharma',
        content: 'Welcome everyone! Today we\'ll cover the first law of thermodynamics.',
        timestamp: new Date(Date.now() - 300000),
        type: 'text'
      },
      {
        id: 'msg-2',
        userId: 'user-3',
        userName: 'Priya Patel',
        content: 'Can you explain the difference between isothermal and adiabatic processes?',
        timestamp: new Date(Date.now() - 240000),
        type: 'text',
        reactions: [{ emoji: '👍', count: 2, users: ['user-1', 'user-4'] }]
      },
      {
        id: 'msg-3',
        userId: 'system',
        userName: 'System',
        content: 'Arjun Singh joined the room',
        timestamp: new Date(Date.now() - 180000),
        type: 'system'
      }
    ];

    setActiveRoom(sampleRoom);
    setParticipants(sampleParticipants);
    setMessages(sampleMessages);
  }, [roomId, userId, userName, isVideoOn, isAudioOn, isScreenSharing, handRaised]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const toggleVideo = () => {
    setIsVideoOn(!isVideoOn);
    // In real implementation, handle WebRTC video stream
  };

  const toggleAudio = () => {
    setIsAudioOn(!isAudioOn);
    // In real implementation, handle WebRTC audio stream
  };

  const toggleScreenShare = () => {
    setIsScreenSharing(!isScreenSharing);
    // In real implementation, handle screen sharing
  };

  const toggleHandRaise = () => {
    setHandRaised(!handRaised);
    // Notify other participants about hand raise
  };

  const sendMessage = () => {
    if (newMessage.trim()) {
      const message: Message = {
        id: `msg-${Date.now()}`,
        userId,
        userName,
        content: newMessage,
        timestamp: new Date(),
        type: 'text'
      };
      setMessages(prev => [...prev, message]);
      setNewMessage('');
    }
  };

  const addReaction = (messageId: string, emoji: string) => {
    setMessages(prev => prev.map(msg => {
      if (msg.id === messageId) {
        const reactions = msg.reactions || [];
        const existingReaction = reactions.find(r => r.emoji === emoji);
        if (existingReaction) {
          if (existingReaction.users.includes(userId)) {
            // Remove reaction
            existingReaction.count--;
            existingReaction.users = existingReaction.users.filter(u => u !== userId);
            if (existingReaction.count === 0) {
              return { ...msg, reactions: reactions.filter(r => r.emoji !== emoji) };
            }
          } else {
            // Add reaction
            existingReaction.count++;
            existingReaction.users.push(userId);
          }
        } else {
          // New reaction
          reactions.push({ emoji, count: 1, users: [userId] });
        }
        return { ...msg, reactions: [...reactions] };
      }
      return msg;
    }));
  };

  const handleCanvasDrawing = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    if (drawingTool === 'pen') {
      ctx.lineTo(x, y);
      ctx.stroke();
    }
  };

  if (!activeRoom) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <Users className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground">Loading study room...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Header */}
      <div className="bg-white border-b p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
              <h1 className="text-xl font-bold">{activeRoom.name}</h1>
              <Badge variant="secondary">{participants.length}/{activeRoom.maxParticipants}</Badge>
            </div>
            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
              <BookOpen className="w-4 h-4" />
              {activeRoom.subject} • {activeRoom.topic}
              <Badge className={`ml-2 ${
                activeRoom.difficulty === 'Beginner' ? 'bg-green-100 text-green-700' :
                activeRoom.difficulty === 'Intermediate' ? 'bg-yellow-100 text-yellow-700' :
                'bg-red-100 text-red-700'
              }`}>
                {activeRoom.difficulty}
              </Badge>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button size="sm" variant="outline">
              <Settings className="w-4 h-4" />
            </Button>
            <Button size="sm" variant="destructive" onClick={onLeaveRoom}>
              <PhoneOff className="w-4 h-4 mr-2" />
              {t.leaveRoom}
            </Button>
          </div>
        </div>

        {/* Control Bar */}
        <div className="flex items-center justify-center space-x-4 mt-4">
          <Button
            variant={isAudioOn ? "default" : "destructive"}
            size="sm"
            onClick={toggleAudio}
          >
            {isAudioOn ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
          </Button>
          
          <Button
            variant={isVideoOn ? "default" : "destructive"}
            size="sm"
            onClick={toggleVideo}
          >
            {isVideoOn ? <Video className="w-4 h-4" /> : <VideoOff className="w-4 h-4" />}
          </Button>
          
          <Button
            variant={isScreenSharing ? "default" : "outline"}
            size="sm"
            onClick={toggleScreenShare}
          >
            <Screen className="w-4 h-4 mr-2" />
            {isScreenSharing ? t.stopSharing : t.shareScreen}
          </Button>
          
          <Button
            variant={handRaised ? "default" : "outline"}
            size="sm"
            onClick={toggleHandRaise}
          >
            <Hand className="w-4 h-4 mr-2" />
            {handRaised ? t.lowerHand : t.raiseHand}
          </Button>
          
          <Button variant="outline" size="sm">
            <Share2 className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex">
        {/* Left Panel - Video & Participants */}
        <div className="w-80 bg-white border-r flex flex-col">
          {/* Video Grid */}
          <div className="p-4 border-b">
            <h3 className="font-semibold mb-3">{t.participants} ({participants.length})</h3>
            <div className="grid grid-cols-2 gap-2">
              {participants.slice(0, 4).map((participant) => (
                <div key={participant.id} className="relative aspect-video bg-gray-100 rounded-lg overflow-hidden">
                  {participant.isVideoOn ? (
                    <div className="w-full h-full bg-gradient-to-br from-blue-400 to-purple-500 flex items-center justify-center">
                      <span className="text-white font-medium">
                        {participant.name.split(' ').map(n => n[0]).join('')}
                      </span>
                    </div>
                  ) : (
                    <div className="w-full h-full bg-gray-200 flex items-center justify-center">
                      <Avatar>
                        <AvatarImage src={participant.avatar} />
                        <AvatarFallback>{participant.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                      </Avatar>
                    </div>
                  )}
                  
                  {/* Participant Status */}
                  <div className="absolute bottom-1 left-1 right-1 flex items-center justify-between">
                    <span className="text-xs text-white bg-black/50 px-1 rounded truncate">
                      {participant.name}
                    </span>
                    <div className="flex items-center space-x-1">
                      {participant.role === 'moderator' && (
                        <Crown className="w-3 h-3 text-yellow-400" />
                      )}
                      {participant.handRaised && (
                        <Hand className="w-3 h-3 text-yellow-400" />
                      )}
                      {!participant.isAudioOn && (
                        <MicOff className="w-3 h-3 text-red-400" />
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Participant List */}
          <div className="flex-1 overflow-y-auto">
            <div className="p-4 space-y-2">
              {participants.map((participant) => (
                <div key={participant.id} className="flex items-center space-x-3 p-2 rounded-lg hover:bg-gray-50">
                  <div className="relative">
                    <Avatar className="w-8 h-8">
                      <AvatarImage src={participant.avatar} />
                      <AvatarFallback className="text-xs">
                        {participant.name.split(' ').map(n => n[0]).join('')}
                      </AvatarFallback>
                    </Avatar>
                    <div className={`absolute -bottom-1 -right-1 w-3 h-3 rounded-full border-2 border-white ${
                      participant.status === 'online' ? 'bg-green-400' :
                      participant.status === 'away' ? 'bg-yellow-400' : 'bg-red-400'
                    }`}></div>
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center space-x-1">
                      <span className="text-sm font-medium truncate">{participant.name}</span>
                      {participant.role === 'moderator' && (
                        <Crown className="w-3 h-3 text-yellow-500" />
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {t[participant.status as keyof typeof t]}
                    </p>
                  </div>
                  
                  <div className="flex items-center space-x-1">
                    {participant.handRaised && (
                      <Hand className="w-4 h-4 text-yellow-500" />
                    )}
                    {participant.isScreenSharing && (
                      <Screen className="w-4 h-4 text-blue-500" />
                    )}
                    <div className="flex items-center">
                      {participant.isAudioOn ? (
                        <Mic className="w-3 h-3 text-green-500" />
                      ) : (
                        <MicOff className="w-3 h-3 text-red-500" />
                      )}
                      {participant.isVideoOn ? (
                        <Video className="w-3 h-3 text-green-500 ml-1" />
                      ) : (
                        <VideoOff className="w-3 h-3 text-red-500 ml-1" />
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Center Panel - Main Content */}
        <div className="flex-1 flex flex-col">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
            <TabsList className="grid w-full grid-cols-3 mx-4 mt-4">
              <TabsTrigger value="whiteboard">{t.whiteboard}</TabsTrigger>
              <TabsTrigger value="chat">{t.chat}</TabsTrigger>
              <TabsTrigger value="resources">{t.resources}</TabsTrigger>
            </TabsList>

            <TabsContent value="whiteboard" className="flex-1 p-4">
              <Card className="h-full">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>{t.whiteboard}</CardTitle>
                    <div className="flex items-center space-x-2">
                      <Button
                        size="sm"
                        variant={drawingTool === 'pen' ? 'default' : 'outline'}
                        onClick={() => setDrawingTool('pen')}
                      >
                        <PenTool className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant={drawingTool === 'eraser' ? 'default' : 'outline'}
                        onClick={() => setDrawingTool('eraser')}
                      >
                        <Eraser className="w-4 h-4" />
                      </Button>
                      <Button size="sm" variant="outline">
                        <Square className="w-4 h-4" />
                      </Button>
                      <Button size="sm" variant="outline">
                        <Circle className="w-4 h-4" />
                      </Button>
                      <Button size="sm" variant="outline">
                        <Type className="w-4 h-4" />
                      </Button>
                      <div className="border-l pl-2 ml-2 flex space-x-1">
                        <Button size="sm" variant="outline">
                          <Undo className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <Redo className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <Save className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="flex-1">
                  <canvas
                    ref={canvasRef}
                    width={800}
                    height={400}
                    className="w-full h-full border rounded cursor-crosshair"
                    onMouseDown={() => setIsDrawing(true)}
                    onMouseUp={() => setIsDrawing(false)}
                    onMouseMove={handleCanvasDrawing}
                  />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="chat" className="flex-1 p-4">
              <Card className="h-full flex flex-col">
                <CardHeader>
                  <CardTitle>{t.chat}</CardTitle>
                </CardHeader>
                <CardContent className="flex-1 flex flex-col">
                  <div className="flex-1 overflow-y-auto mb-4 space-y-3">
                    {messages.map((message) => (
                      <div key={message.id} className={`flex ${message.type === 'system' ? 'justify-center' : 'justify-start'}`}>
                        {message.type === 'system' ? (
                          <div className="text-xs text-muted-foreground bg-gray-100 px-2 py-1 rounded">
                            {message.content}
                          </div>
                        ) : (
                          <div className="max-w-xs lg:max-w-md">
                            <div className="flex items-center space-x-2 mb-1">
                              <span className="text-sm font-medium">{message.userName}</span>
                              <span className="text-xs text-muted-foreground">
                                {message.timestamp.toLocaleTimeString()}
                              </span>
                            </div>
                            <div className="bg-white border rounded-lg p-3">
                              <p className="text-sm">{message.content}</p>
                              {message.reactions && message.reactions.length > 0 && (
                                <div className="flex items-center space-x-2 mt-2">
                                  {message.reactions.map((reaction, index) => (
                                    <button
                                      key={index}
                                      className="flex items-center space-x-1 text-xs bg-gray-100 hover:bg-gray-200 rounded-full px-2 py-1"
                                      onClick={() => addReaction(message.id, reaction.emoji)}
                                    >
                                      <span>{reaction.emoji}</span>
                                      <span>{reaction.count}</span>
                                    </button>
                                  ))}
                                </div>
                              )}
                              <div className="flex items-center space-x-2 mt-2">
                                <button onClick={() => addReaction(message.id, '👍')}>👍</button>
                                <button onClick={() => addReaction(message.id, '❤️')}>❤️</button>
                                <button onClick={() => addReaction(message.id, '😊')}>😊</button>
                                <button onClick={() => addReaction(message.id, '🤔')}>🤔</button>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                    <div ref={messagesEndRef} />
                  </div>
                  
                  <div className="flex space-x-2">
                    <input
                      type="text"
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      placeholder={t.typeMessage}
                      className="flex-1 p-2 border rounded-lg"
                      onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                    />
                    <Button onClick={sendMessage} disabled={!newMessage.trim()}>
                      <Send className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="resources" className="flex-1 p-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 h-full">
                <Card>
                  <CardHeader>
                    <CardTitle>{t.roomInfo}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-medium mb-2">Description</h4>
                        <p className="text-sm text-muted-foreground">{activeRoom.description}</p>
                      </div>
                      <div>
                        <h4 className="font-medium mb-2">Details</h4>
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span>Subject:</span>
                            <span>{activeRoom.subject}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Topic:</span>
                            <span>{activeRoom.topic}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Exam:</span>
                            <span>{activeRoom.examType}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Difficulty:</span>
                            <span>{activeRoom.difficulty}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>{t.studyProgress}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between mb-2">
                          <span className="text-sm">{t.timeSpent}</span>
                          <span className="text-sm font-medium">2h 15m</span>
                        </div>
                        <Progress value={75} />
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4 text-center">
                        <div className="p-3 bg-blue-50 rounded-lg">
                          <div className="text-2xl font-bold text-blue-600">12</div>
                          <div className="text-xs text-blue-700">{t.questionsAsked}</div>
                        </div>
                        <div className="p-3 bg-green-50 rounded-lg">
                          <div className="text-2xl font-bold text-green-600">8</div>
                          <div className="text-xs text-green-700">{t.conceptsCovered}</div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
