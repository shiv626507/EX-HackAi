import { useState, useRef, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Upload, 
  Mic, 
  Video, 
  FileText, 
  Image, 
  Play, 
  Pause, 
  Square, 
  Trash2, 
  Download,
  Send,
  Camera,
  Volume2,
  FileVideo,
  FilePdf,
  FileAudio,
  Loader2,
  CheckCircle,
  XCircle,
  Eye,
  MessageSquare
} from "lucide-react";

interface MediaFile {
  id: string;
  type: 'text' | 'audio' | 'video' | 'pdf' | 'image';
  name: string;
  size: number;
  url: string;
  duration?: number;
  processing?: boolean;
  processed?: boolean;
  transcription?: string;
  summary?: string;
  error?: string;
}

interface MultimediaInputProps {
  onFileProcessed?: (file: MediaFile) => void;
  onAIQuery?: (query: string, context: MediaFile[]) => void;
  acceptedTypes?: string[];
  maxFileSize?: number; // in MB
  language?: 'en' | 'hi';
}

export default function MultimediaInput({
  onFileProcessed,
  onAIQuery,
  acceptedTypes = ['text', 'audio', 'video', 'pdf', 'image'],
  maxFileSize = 50,
  language = 'en'
}: MultimediaInputProps) {
  const [files, setFiles] = useState<MediaFile[]>([]);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [query, setQuery] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordingIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const texts = {
    en: {
      uploadFiles: "Upload Files",
      recordAudio: "Record Audio",
      recordVideo: "Record Video",
      takePhoto: "Take Photo",
      dragDrop: "Drag and drop files here or click to browse",
      supportedFormats: "Supported formats",
      askAI: "Ask AI",
      typeQuestion: "Type your question about the uploaded content...",
      processing: "Processing",
      transcribing: "Transcribing audio",
      extracting: "Extracting text",
      analyzing: "Analyzing content",
      startRecording: "Start Recording",
      stopRecording: "Stop Recording",
      recording: "Recording",
      preview: "Preview",
      remove: "Remove",
      download: "Download",
      maxSize: `Max file size: ${maxFileSize}MB`,
      fileError: "File processing failed",
      sizeLimitError: `File size exceeds ${maxFileSize}MB limit`,
      typeError: "File type not supported"
    },
    hi: {
      uploadFiles: "फाइलें अपलोड करें",
      recordAudio: "ऑडियो रिकॉर्ड करें",
      recordVideo: "वीडियो रिकॉर्ड करें",
      takePhoto: "फोटो लें",
      dragDrop: "यहाँ फाइलें खींचें या ब्राउज़ करने के लिए क्लिक करें",
      supportedFormats: "समर्थित प्रारूप",
      askAI: "AI से पूछें",
      typeQuestion: "अपलोड की गई सामग्री के बारे में अपना प्रश्न टाइप करें...",
      processing: "प्रसंस्करण",
      transcribing: "ऑडियो का प्रतिलेखन",
      extracting: "टेक्स्ट निकाला जा रहा है",
      analyzing: "सामग्री का विश्लेषण",
      startRecording: "रिकॉर्डिंग शुरू करें",
      stopRecording: "रिकॉर्डिंग बंद करें",
      recording: "रिकॉर्डिंग",
      preview: "पूर्वावलोकन",
      remove: "हटाएं",
      download: "डाउनलोड",
      maxSize: `अधिकतम फाइल आकार: ${maxFileSize}MB`,
      fileError: "फाइल प्रसंस्करण विफल",
      sizeLimitError: `फाइल का आकार ${maxFileSize}MB की सीमा से अधिक है`,
      typeError: "फाइल प्रकार समर्थित नहीं है"
    }
  };

  const t = texts[language];

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const formatDuration = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getFileTypeIcon = (type: string) => {
    switch (type) {
      case 'audio': return <FileAudio className="w-6 h-6" />;
      case 'video': return <FileVideo className="w-6 h-6" />;
      case 'pdf': return <FilePdf className="w-6 h-6" />;
      case 'image': return <Image className="w-6 h-6" />;
      default: return <FileText className="w-6 h-6" />;
    }
  };

  const validateFile = (file: File): boolean => {
    // Check file size
    if (file.size > maxFileSize * 1024 * 1024) {
      alert(t.sizeLimitError);
      return false;
    }

    // Check file type
    const fileType = file.type.split('/')[0];
    const extension = file.name.split('.').pop()?.toLowerCase();
    
    if (extension === 'pdf' && !acceptedTypes.includes('pdf')) return false;
    if (fileType === 'text' && !acceptedTypes.includes('text')) return false;
    if (fileType === 'audio' && !acceptedTypes.includes('audio')) return false;
    if (fileType === 'video' && !acceptedTypes.includes('video')) return false;
    if (fileType === 'image' && !acceptedTypes.includes('image')) return false;

    return true;
  };

  const processFile = async (file: File): Promise<MediaFile> => {
    const id = Date.now().toString();
    const url = URL.createObjectURL(file);
    let type: MediaFile['type'] = 'text';
    
    const fileType = file.type.split('/')[0];
    const extension = file.name.split('.').pop()?.toLowerCase();
    
    if (extension === 'pdf') type = 'pdf';
    else if (fileType === 'audio') type = 'audio';
    else if (fileType === 'video') type = 'video';
    else if (fileType === 'image') type = 'image';

    const mediaFile: MediaFile = {
      id,
      type,
      name: file.name,
      size: file.size,
      url,
      processing: true
    };

    setFiles(prev => [...prev, mediaFile]);

    try {
      // Simulate AI processing based on file type
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      let processedData: Partial<MediaFile> = {};

      switch (type) {
        case 'audio':
        case 'video':
          // Simulate audio transcription
          processedData = {
            transcription: "This is a sample transcription of the audio/video content. In a real implementation, this would be generated using Whisper AI or similar speech-to-text service.",
            summary: "Key concepts discussed: Physics formulas, thermodynamics principles, and problem-solving techniques.",
            duration: 120 // 2 minutes
          };
          break;
        case 'pdf':
          // Simulate PDF text extraction
          processedData = {
            transcription: "This is extracted text from the PDF document. In a real implementation, this would use PDF parsing libraries to extract text content.",
            summary: "Document contains: Study materials, practice questions, and concept explanations."
          };
          break;
        case 'image':
          // Simulate OCR and image analysis
          processedData = {
            transcription: "Text extracted from image using OCR. Mathematical equations and diagrams detected.",
            summary: "Image contains: Mathematical formulas, diagrams, and handwritten notes."
          };
          break;
      }

      const updatedFile = {
        ...mediaFile,
        ...processedData,
        processing: false,
        processed: true
      };

      setFiles(prev => prev.map(f => f.id === id ? updatedFile : f));
      onFileProcessed?.(updatedFile);

      return updatedFile;
    } catch (error) {
      const errorFile = {
        ...mediaFile,
        processing: false,
        error: t.fileError
      };
      setFiles(prev => prev.map(f => f.id === id ? errorFile : f));
      throw error;
    }
  };

  const handleFileUpload = useCallback(async (uploadedFiles: FileList | null) => {
    if (!uploadedFiles) return;

    for (let i = 0; i < uploadedFiles.length; i++) {
      const file = uploadedFiles[i];
      if (validateFile(file)) {
        await processFile(file);
      }
    }
  }, []);

  const startAudioRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;

      const chunks: Blob[] = [];
      mediaRecorder.ondataavailable = (event) => {
        chunks.push(event.data);
      };

      mediaRecorder.onstop = async () => {
        const blob = new Blob(chunks, { type: 'audio/wav' });
        const file = new File([blob], `recording-${Date.now()}.wav`, { type: 'audio/wav' });
        await processFile(file);
        setRecordingDuration(0);
      };

      mediaRecorder.start();
      setIsRecording(true);

      // Start duration counter
      recordingIntervalRef.current = setInterval(() => {
        setRecordingDuration(prev => prev + 1);
      }, 1000);
    } catch (error) {
      console.error('Error starting recording:', error);
      alert('Could not access microphone. Please check permissions.');
    }
  };

  const stopAudioRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      mediaRecorderRef.current.stream.getTracks().forEach(track => track.stop());
      setIsRecording(false);
      
      if (recordingIntervalRef.current) {
        clearInterval(recordingIntervalRef.current);
      }
    }
  };

  const removeFile = (fileId: string) => {
    setFiles(prev => {
      const file = prev.find(f => f.id === fileId);
      if (file) {
        URL.revokeObjectURL(file.url);
      }
      return prev.filter(f => f.id !== fileId);
    });
  };

  const handleAIQuery = () => {
    if (query.trim() && onAIQuery) {
      setIsProcessing(true);
      onAIQuery(query, files);
      setTimeout(() => setIsProcessing(false), 2000);
    }
  };

  return (
    <div className="space-y-6">
      {/* Upload Area */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Upload className="w-5 h-5 mr-2" />
            {t.uploadFiles}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div
            className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-primary transition-colors cursor-pointer"
            onClick={() => fileInputRef.current?.click()}
            onDrop={(e) => {
              e.preventDefault();
              handleFileUpload(e.dataTransfer.files);
            }}
            onDragOver={(e) => e.preventDefault()}
          >
            <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600 mb-2">{t.dragDrop}</p>
            <p className="text-sm text-gray-500 mb-4">{t.maxSize}</p>
            
            <div className="flex flex-wrap gap-2 justify-center">
              {acceptedTypes.map(type => (
                <Badge key={type} variant="outline">
                  {type.toUpperCase()}
                </Badge>
              ))}
            </div>
          </div>
          
          <input
            ref={fileInputRef}
            type="file"
            multiple
            className="hidden"
            accept={acceptedTypes.includes('pdf') ? '.pdf,image/*,audio/*,video/*,.txt' : 'image/*,audio/*,video/*,.txt'}
            onChange={(e) => handleFileUpload(e.target.files)}
          />
        </CardContent>
      </Card>

      {/* Recording Controls */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4">
            <Button
              className="w-full"
              variant={isRecording ? "destructive" : "outline"}
              onClick={isRecording ? stopAudioRecording : startAudioRecording}
            >
              {isRecording ? (
                <>
                  <Square className="w-4 h-4 mr-2" />
                  {t.stopRecording} ({formatDuration(recordingDuration)})
                </>
              ) : (
                <>
                  <Mic className="w-4 h-4 mr-2" />
                  {t.recordAudio}
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <Button className="w-full" variant="outline" disabled>
              <Video className="w-4 h-4 mr-2" />
              {t.recordVideo}
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <Button className="w-full" variant="outline" disabled>
              <Camera className="w-4 h-4 mr-2" />
              {t.takePhoto}
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* File List */}
      {files.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Uploaded Files ({files.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {files.map((file) => (
                <div key={file.id} className="flex items-center space-x-4 p-4 border rounded-lg">
                  <div className="flex-shrink-0">
                    {getFileTypeIcon(file.type)}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate">{file.name}</p>
                    <p className="text-sm text-gray-500">
                      {formatFileSize(file.size)}
                      {file.duration && ` • ${formatDuration(file.duration)}`}
                    </p>
                    
                    {file.processing && (
                      <div className="mt-2">
                        <div className="flex items-center space-x-2">
                          <Loader2 className="w-4 h-4 animate-spin" />
                          <span className="text-sm">{t.processing}...</span>
                        </div>
                        <Progress value={65} className="mt-2 h-2" />
                      </div>
                    )}
                    
                    {file.processed && file.transcription && (
                      <div className="mt-2 p-2 bg-gray-50 rounded text-sm">
                        <p className="text-gray-700">{file.transcription.substring(0, 100)}...</p>
                      </div>
                    )}
                    
                    {file.error && (
                      <div className="mt-2 flex items-center text-red-600">
                        <XCircle className="w-4 h-4 mr-1" />
                        <span className="text-sm">{file.error}</span>
                      </div>
                    )}
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    {file.processed && (
                      <CheckCircle className="w-5 h-5 text-green-500" />
                    )}
                    <Button size="sm" variant="outline">
                      <Eye className="w-4 h-4" />
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => removeFile(file.id)}>
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* AI Query Interface */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <MessageSquare className="w-5 h-5 mr-2" />
            {t.askAI}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex space-x-2">
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={t.typeQuestion}
              className="flex-1 p-3 border rounded-lg"
              onKeyPress={(e) => e.key === 'Enter' && handleAIQuery()}
            />
            <Button 
              onClick={handleAIQuery} 
              disabled={!query.trim() || isProcessing}
            >
              {isProcessing ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Send className="w-4 h-4" />
              )}
            </Button>
          </div>
          
          {files.length > 0 && (
            <div className="mt-3">
              <p className="text-sm text-gray-600">
                Context: {files.length} file(s) uploaded
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
